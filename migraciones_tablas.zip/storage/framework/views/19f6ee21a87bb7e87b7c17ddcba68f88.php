<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <h2>Actualizar un personal</h2>
        <div>
            <a href="<?php echo e(url('/personal')); ?>" class="btn btn-primary"> Atras </a>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('dinamic-content'); ?>
    <form action=<?php echo e(url('/personal/'. $personal->id)); ?> method="POST" enctype="multipart/form-data">
        <?php echo e(method_field('PATCH')); ?>

        <?php echo e(csrf_field()); ?>

        <?php echo $__env->make('personal.form-personal', ['formMode' => 'edit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>

    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/personal.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/personal/edit-personal.blade.php ENDPATH**/ ?>