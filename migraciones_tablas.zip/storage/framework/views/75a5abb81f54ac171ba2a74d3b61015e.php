<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <h2>Roles</h2>
        <div>
            <a href="<?php echo e('roles/create'); ?>" class="btn btn-primary"> Agregar </a>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('dinamic-content'); ?>
    <?php if (isset($component)) { $__componentOriginal1f0f987500f76b1f57bfad21f77af286 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f0f987500f76b1f57bfad21f77af286 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::resolve(['id' => 'tableRoles','heads' => $heads] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($rol->id); ?></td>
                <td>
                    <?php if($rol->name === 'Super-Admin'): ?>
                        <p>
                            <?php echo e($rol->name); ?>

                            <i class="fas fa-star text-warning"></i>
                        </p>
                    <?php else: ?>
                        <a href="<?php echo e(url('roles/grupos/' . $rol->id)); ?>">
                            <?php echo e($rol->name); ?>

                        </a>
                    <?php endif; ?>

                </td>
                <td><?php echo e($usersCountByRoles[$rol->name]); ?></td>

                <?php if($rol->name !== 'Super-Admin'): ?>
                    <td>
                        <a href="<?php echo e(url('/roles/' . $rol->id . '/edit')); ?>"> <i class="fa-solid fa-pen-to-square"></i> </a>
                        <form action="<?php echo e(url('/roles/' . $rol->id)); ?>" class="form-delete" method="POST"
                            style="display: inline;" data-confirm-delete="true">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                style="border: none; background: none; padding: 0; margin: 0; cursor: pointer;"> <i class="fas fa-trash text-primary"></i> </button>
                        </form>

                    </td>
                <?php endif; ?>


            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f0f987500f76b1f57bfad21f77af286)): ?>
<?php $attributes = $__attributesOriginal1f0f987500f76b1f57bfad21f77af286; ?>
<?php unset($__attributesOriginal1f0f987500f76b1f57bfad21f77af286); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f0f987500f76b1f57bfad21f77af286)): ?>
<?php $component = $__componentOriginal1f0f987500f76b1f57bfad21f77af286; ?>
<?php unset($__componentOriginal1f0f987500f76b1f57bfad21f77af286); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>


    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            Swal.fire({
                title: "Eliminado!",
                text: "tu registro fue eliminado.",
                icon: "success"
            });
        </script>
    <?php endif; ?>
    <script>
        $('.form-delete').submit(function(e) {
            e.preventDefault();
            Swal.fire({
                title: "¿Estas seguro?",
                text: "Si eliminas no podras revertirlo",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Si, Eliminar!",
                cancelButtonText: "Descartar"
            }).then((result) => {
                if (result.isConfirmed) {
                    this.submit();
                }
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/roles/list-roles.blade.php ENDPATH**/ ?>