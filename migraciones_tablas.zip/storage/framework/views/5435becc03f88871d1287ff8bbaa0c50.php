<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <h2>Registra un incoterm</h2>
        <div>
            <a href="<?php echo e(url('/incoterms')); ?>" class="btn btn-primary"> Atras </a>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('dinamic-content'); ?>
    <form action="/incoterms" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('incoterms.form-incoterm', ['formMode' => 'create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/incoterms/register-incoterm.blade.php ENDPATH**/ ?>