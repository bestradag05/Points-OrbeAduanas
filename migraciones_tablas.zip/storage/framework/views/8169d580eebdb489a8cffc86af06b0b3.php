<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <h2>Detalle del Routing</h2>
        <div>
            <button class="btn btn-primary"> Atras </button>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('dinamic-content'); ?>

    <div class="card card-primary card-outline card-outline-tabs">
        <div class="card-header p-0 border-bottom-0">
            <ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link <?php echo e($tab == 'detail' ? 'active' : ''); ?>" href="<?php echo e(url('/routing/' . $routing->id . '/detail')); ?>">
                        Detalle</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($tab == 'detail' ? '' : 'active'); ?>" href="<?php echo e(url('/routing/' . $routing->id . '/documents')); ?>">
                        Documentos
                    </a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content" id="custom-tabs-four-tabContent">
                <div class="tab-pane fade show active" id="custom-tabs-four-detail" role="tabpanel"
                    aria-labelledby="custom-tabs-four-detail-tab">

                    <?php if($tab == 'detail'): ?>
                        <?php echo $__env->make('routing/templates/template-detail-routing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php else: ?>
                        <?php echo $__env->make('routing/templates/template-documents-routing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>

                </div>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/routing/detail-routing.blade.php ENDPATH**/ ?>