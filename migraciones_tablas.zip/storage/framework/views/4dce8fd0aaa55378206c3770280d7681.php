<!--Card Contend de usuarios -->



<form action="<?php echo e(url('/roles/grupos/' . $rol)); ?>" method="POST" class="row justify-content-around">
    <?php echo csrf_field(); ?>
    <div class="col-6">
        <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'user','igroupSize' => 'md'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Select un usuario...']); ?>
             <?php $__env->slot('prependSlot', null, []); ?> 
                <div class="input-group-text">
                    <i class="fa-solid fa-users mr-2"></i>
                </div>
             <?php $__env->endSlot(); ?>
            <option />

            <?php $__currentLoopData = $personals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
                <?php if($personal->user && !$personal->user->hasRole($rol->name)): ?>
                    <option value="<?php echo e($personal->user->id); ?>"><?php echo e($personal->names . ' ' . $personal->last_name); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
    </div>
    <div class="col-2 d-flex align-items-center">
        <button type="submit" class="btn btn-block btn-indigo btn-md">Agregar</button>
    </div>
</form>

<div class="card ">
    <div class="card-header d-flex align-items-center">
        <p class="mb-0 pb-0  ">Listado de usuarios de este grupo</p>
    </div>
    <div class="card-body">
        <?php if (isset($component)) { $__componentOriginal1f0f987500f76b1f57bfad21f77af286 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f0f987500f76b1f57bfad21f77af286 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::resolve(['id' => 'UserHasRole','heads' => $headsRolUser] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php $__currentLoopData = $userHasRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userHasRole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($loop->iteration); ?></td>
                    <td> <?php echo e($userHasRole->personal->name . ' ' . $userHasRole->personal->last_name); ?>

                    </td>
                    <td>
                            <img src="<?php echo e(asset('storage/' . ($userHasRole->personal->img_url !== null ? $userHasRole->personal->img_url : 'personals/user_default.png'))); ?>" class="img-circle elevation-2" width="50px" height="50px" alt="User Image">
                        </td>
                    <td>
                        <form action="<?php echo e(url('/roles/grupos/' . $rol->id)); ?>" class="form-delete" method="POST"
                            style="display: inline;" data-confirm-delete="true">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($userHasRole->id); ?>" name="id_user">
                            <button type="submit"
                                style="border: none; background: none; padding: 0; margin: 0; cursor: pointer;">
                                <i class="fa-regular fa-circle-minus"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f0f987500f76b1f57bfad21f77af286)): ?>
<?php $attributes = $__attributesOriginal1f0f987500f76b1f57bfad21f77af286; ?>
<?php unset($__attributesOriginal1f0f987500f76b1f57bfad21f77af286); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f0f987500f76b1f57bfad21f77af286)): ?>
<?php $component = $__componentOriginal1f0f987500f76b1f57bfad21f77af286; ?>
<?php unset($__componentOriginal1f0f987500f76b1f57bfad21f77af286); ?>
<?php endif; ?>
    </div>
</div>
<!-- Fin card content de usuarios -->
<?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/roles/form-group-roles.blade.php ENDPATH**/ ?>