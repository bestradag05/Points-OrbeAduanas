            
            <?php if (isset($component)) { $__componentOriginale2dfb698641700bc6575e0f9f2d3d632 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2dfb698641700bc6575e0f9f2d3d632 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Tool\Modal::resolve(['id' => 'modalAduanas','title' => 'Aduana','size' => 'lg','scrollable' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Tool\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'modal']); ?>
                <form action="/routing_service" method="POST">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="nro_operation" value="<?php echo e($routing->nro_operation); ?>">
                    <input type="hidden" name="typeService" id="typeService">

                    <div class="col-12">

                        <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'modality','id' => 'modality','label' => 'Modalidad'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione un concepto...']); ?>
                            <option />
                            <?php $__currentLoopData = $modalitys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($modality->id); ?>"><?php echo e($modality->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>

                    </div>

                    <div class="form-group">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" name="state_insurance" class="custom-control-input" id="seguroCustom"
                                onchange="enableInsurance(this)">
                            <label class="custom-control-label" for="seguroCustom">Agregar Seguro</label>
                        </div>
                    </div>
                    <hr>
                    <div class="row d-none justify-content-center" id="content_seguroCustom">
                        <div class="col-3">
                            <label for="type_insurance">Tipo de seguro</label>
                            <select name="type_insurance" class="d-none form-control" label="Tipo de seguro"
                                igroup-size="md" data-placeholder="Seleccione una opcion...">
                                <option />
                                <?php $__currentLoopData = $type_insurace; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <label for="load_value">Valor del seguro</label>

                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-bold">
                                            $
                                        </span>
                                    </div>
                                    <input type="text" class="form-control CurrencyInput d-none "
                                        name="value_insurance" data-type="currency"
                                        placeholder="Ingrese valor de la carga" onchange="updateInsuranceTotal(this)">
                                </div>

                            </div>
                        </div>

                        <div class="col-3">
                            <div class="form-group">
                                <label for="load_value">Valor ha agregar</label>

                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-bold">
                                            $
                                        </span>
                                    </div>
                                    <input type="text" class="form-control CurrencyInput d-none" id="insurance_added"
                                        name="insurance_added" data-type="currency" value="0"
                                        placeholder="Ingrese valor de la carga"
                                        onchange="updateInsuranceAddedTotal(this)">
                                </div>

                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <label for="load_value">Puntos</label>

                                <div class="input-group">
                                    <input type="number" class="form-control d-none" id="insurance_points"
                                        name="insurance_points" min="0" onkeydown="preventeDefaultAction(event)"
                                        oninput="addPointsInsurance(this)">
                                </div>

                            </div>
                        </div>
                    </div>

                    <hr>
                    <div id="formConceptsAduanas" class="formConcepts row">
                        <div class="col-4">

                            <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'concept','id' => 'concept_aduana','label' => 'Conceptos'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione un concepto...']); ?>
                                <option />
                                <?php $__currentLoopData = $concepts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($concept->typeService->name == 'Aduanas' && $routing->type_shipment->id == $concept->id_type_shipment): ?>
                                        <option value="<?php echo e($concept->id); ?>"><?php echo e($concept->name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>

                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label for="value_concept">Valor del neto del concepto</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-bold">
                                            $
                                        </span>
                                    </div>
                                    <input type="text" class="form-control CurrencyInput " name="value_concept"
                                        data-type="currency" placeholder="Ingrese valor del concepto" value="">
                                </div>
                            </div>

                        </div>

                        <div class="col-4">
                            <div class="form-group">
                                <label for="value_concept">Valor ha agregar</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-bold">
                                            $
                                        </span>
                                    </div>
                                    <input type="text" class="form-control CurrencyInput " name="value_added"
                                        data-type="currency" placeholder="Ingrese valor agregado" value="0">
                                </div>
                            </div>

                        </div>
                        <div class="col-12 d-flex justify-content-center align-items-center pt-3 mb-2">
                            <button class="btn btn-indigo" type="button" id="btnAddConcept"
                                onclick="addConcept(this)">
                                Agregar
                            </button>

                        </div>

                        <table class="table">
                            <thead>
                                <tr>
                                    <th style="width: 10px">#</th>
                                    <th>Concepto</th>
                                    <th>Valor del concepto</th>
                                    <th>Valor agregado</th>
                                    <th>x</th>
                                </tr>
                            </thead>
                            <tbody id="tbodyAduanas">


                            </tbody>
                        </table>

                        <div class="row w-100 justify-content-end">

                            <div class="col-4 row">
                                <label for="total" class="col-sm-4 col-form-label">Total:</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="total" name="totalCustom"
                                        value="0.00" <?php if(true): echo 'readonly'; endif; ?>>
                                </div>
                            </div>

                        </div>


                    </div>

                     <?php $__env->slot('footerSlot', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginal84b78d66d5203b43b9d8c22236838526 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84b78d66d5203b43b9d8c22236838526 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Button::resolve(['type' => 'submit','label' => 'Guardar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn btn-indigo','id' => 'btnSubmit','onclick' => 'submitForm(this)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $attributes = $__attributesOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__attributesOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $component = $__componentOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__componentOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal84b78d66d5203b43b9d8c22236838526 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84b78d66d5203b43b9d8c22236838526 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Button::resolve(['theme' => 'secondary','label' => 'Cerrar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-dismiss' => 'modal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $attributes = $__attributesOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__attributesOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $component = $__componentOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__componentOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
                     <?php $__env->endSlot(); ?>

                </form>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2dfb698641700bc6575e0f9f2d3d632)): ?>
<?php $attributes = $__attributesOriginale2dfb698641700bc6575e0f9f2d3d632; ?>
<?php unset($__attributesOriginale2dfb698641700bc6575e0f9f2d3d632); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2dfb698641700bc6575e0f9f2d3d632)): ?>
<?php $component = $__componentOriginale2dfb698641700bc6575e0f9f2d3d632; ?>
<?php unset($__componentOriginale2dfb698641700bc6575e0f9f2d3d632); ?>
<?php endif; ?>

            
            <?php if (isset($component)) { $__componentOriginale2dfb698641700bc6575e0f9f2d3d632 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2dfb698641700bc6575e0f9f2d3d632 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Tool\Modal::resolve(['id' => 'modalFlete','title' => 'Flete','size' => 'lg','scrollable' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Tool\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'modal']); ?>
                <form action="/routing_service" method="POST">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="nro_operation" value="<?php echo e($routing->nro_operation); ?>">
                    <input type="hidden" name="typeService" id="typeService">

                    <div class="row">

                        <div class="col-12">

                            <div class="form-group">
                                <label for="utility">Utilidad Orbe</label>

                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-bold">
                                            $
                                        </span>
                                    </div>
                                    <input type="text" class="form-control CurrencyInput" id="utility"
                                        name="utility" data-type="currency"
                                        placeholder="Ingrese valor de la utilidad">

                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" name="state_insurance" class="custom-control-input"
                                id="seguroFreight" onchange="enableInsurance(this)">
                            <label class="custom-control-label" for="seguroFreight">Agregar Seguro</label>
                        </div>
                    </div>

                    <hr>
                    <div class="row d-none justify-content-center" id="content_seguroFreight">
                        <div class="col-3">
                            <label for="type_insurance">Tipo de seguro</label>
                            <select name="type_insurance" class="d-none form-control" label="Tipo de seguro"
                                igroup-size="md" data-placeholder="Seleccione una opcion...">
                                <option />
                                <?php $__currentLoopData = $type_insurace; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <label for="load_value">Valor del seguro</label>

                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-bold">
                                            $
                                        </span>
                                    </div>
                                    <input type="text" class="form-control CurrencyInput d-none "
                                        name="value_insurance" data-type="currency"
                                        placeholder="Ingrese valor de la carga" onchange="updateInsuranceTotal(this)">
                                </div>

                            </div>
                        </div>

                        <div class="col-3">
                            <div class="form-group">
                                <label for="load_value">Valor ha agregar</label>

                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-bold">
                                            $
                                        </span>
                                    </div>
                                    <input type="text" class="form-control CurrencyInput d-none"
                                        id="insurance_added" name="insurance_added" data-type="currency"
                                        value="0" placeholder="Ingrese valor de la carga"
                                        onchange="updateInsuranceAddedTotal(this)">
                                </div>

                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <label for="load_value">Puntos</label>

                                <div class="input-group">
                                    <input type="number" class="form-control d-none" id="insurance_points"
                                        name="insurance_points" min="0"
                                        onkeydown="preventeDefaultAction(event)" oninput="addPointsInsurance(this)">
                                </div>

                            </div>
                        </div>
                    </div>

                    <hr>

                    <div id="formConceptsFlete" class="formConcepts row">
                        <div class="col-4">

                            <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'concept','id' => 'concept_flete','label' => 'Conceptos'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione un concepto...']); ?>
                                <option />
                                <?php $__currentLoopData = $concepts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($concept->typeService->name == 'Flete' && $routing->type_shipment->id == $concept->id_type_shipment): ?>
                                        <option value="<?php echo e($concept->id); ?>"><?php echo e($concept->name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>

                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label for="value_concept">Valor del neto del concepto</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-bold">
                                            $
                                        </span>
                                    </div>
                                    <input type="text" class="form-control CurrencyInput " name="value_concept"
                                        data-type="currency" placeholder="Ingrese valor del concepto" value="">
                                </div>
                            </div>

                        </div>

                        <div class="col-4">
                            <div class="form-group">
                                <label for="value_concept">Valor ha agregar</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-bold">
                                            $
                                        </span>
                                    </div>
                                    <input type="text" class="form-control CurrencyInput " name="value_added"
                                        data-type="currency" placeholder="Ingrese valor agregado" value="0">
                                </div>
                            </div>

                        </div>
                        <div class="col-12 d-flex justify-content-center align-items-center pt-3 mb-2">
                            <button class="btn btn-indigo" type="button" id="btnAddConcept"
                                onclick="addConcept(this)">
                                Agregar
                            </button>

                        </div>

                        <table class="table">
                            <thead>
                                <tr>
                                    <th style="width: 10px">#</th>
                                    <th>Concepto</th>
                                    <th>Valor del concepto</th>
                                    <th>Valor agregado</th>
                                    <th>Puntos Adicionales</th>
                                    <th>x</th>
                                </tr>
                            </thead>
                            <tbody id="tbodyFlete">


                            </tbody>
                        </table>


                        <div class="row w-100 justify-content-end">

                            <div class="col-4 row">
                                <label for="total" class="col-sm-4 col-form-label">Total:</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="total" id="total"
                                        value="0.00" <?php if(true): echo 'readonly'; endif; ?>>
                                </div>
                            </div>

                        </div>

                    </div>

                     <?php $__env->slot('footerSlot', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginal84b78d66d5203b43b9d8c22236838526 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84b78d66d5203b43b9d8c22236838526 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Button::resolve(['type' => 'submit','label' => 'Guardar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn btn-indigo','id' => 'btnSubmit','onclick' => 'submitForm(this)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $attributes = $__attributesOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__attributesOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $component = $__componentOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__componentOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal84b78d66d5203b43b9d8c22236838526 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84b78d66d5203b43b9d8c22236838526 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Button::resolve(['theme' => 'secondary','label' => 'Cerrar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-dismiss' => 'modal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $attributes = $__attributesOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__attributesOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $component = $__componentOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__componentOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
                     <?php $__env->endSlot(); ?>

                </form>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2dfb698641700bc6575e0f9f2d3d632)): ?>
<?php $attributes = $__attributesOriginale2dfb698641700bc6575e0f9f2d3d632; ?>
<?php unset($__attributesOriginale2dfb698641700bc6575e0f9f2d3d632); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2dfb698641700bc6575e0f9f2d3d632)): ?>
<?php $component = $__componentOriginale2dfb698641700bc6575e0f9f2d3d632; ?>
<?php unset($__componentOriginale2dfb698641700bc6575e0f9f2d3d632); ?>
<?php endif; ?>


            
            <?php if (isset($component)) { $__componentOriginale2dfb698641700bc6575e0f9f2d3d632 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2dfb698641700bc6575e0f9f2d3d632 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Tool\Modal::resolve(['id' => 'modalTransporte','title' => 'Transporte','size' => 'lg','scrollable' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Tool\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'modal']); ?>

                <form action="/routing_service" method="POST">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="nro_operation" value="<?php echo e($routing->nro_operation); ?>">
                    <input type="hidden" name="typeService" id="typeService">
                    <?php if(isset($cost_transport)): ?>
                    <input type="hidden" name="id_quote_transport" id="id_quote_transport">
                    <?php endif; ?>

                    <div class="row">

                        <div class="col-4">
                            <div class="form-group">
                                <label for="transport_value">Valor del Transporte</label>

                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-bold">
                                            $
                                        </span>
                                    </div>
                                    <input type="text" class="form-control CurrencyInput" id="transport_value"
                                        name="transport_value" onchange="updateTransportTotal(this)"
                                        data-type="currency" placeholder="Ingrese valor del flete">

                                    <?php $__errorArgs = ['transport_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                        </div>

                        <div class="col-4">
                            <div class="form-group">
                                <label for="load_value">Valor ha agregar</label>

                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-bold">
                                            $
                                        </span>
                                    </div>
                                    <input type="text" class="form-control CurrencyInput" id="transport_added"
                                        name="transport_added" data-type="currency"
                                        placeholder="Ingrese valor de la carga"
                                        onchange="updateTransportAddedTotal(this)">

                                </div>

                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label for="load_value">Puntos</label>

                                <div class="input-group">
                                    <input type="number" class="form-control" id="additional_points"
                                        name="additional_points" min="0"
                                        onkeydown="preventeDefaultAction(event)" oninput="addPointsTransport(this)">
                                </div>

                            </div>
                        </div>



                        <div class="col-4">

                            <div class="form-group">
                                <label for="origin">Recojo</label>
                                <input type="text" class="form-control" id="origin" name="origin"
                                    placeholder="Ingrese el origin">

                                <?php $__errorArgs = ['origin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                        </div>
                        <div class="col-4">

                            <div class="form-group">
                                <label for="destination">Destino</label>

                                <input type="text" class="form-control" id="destination" name="destination"
                                    placeholder="Ingrese el destino">


                                <?php $__errorArgs = ['destination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                        </div>
                        <div class="col-4">

                            <div class="form-group">
                                <label for="withdrawal_date">Fecha de retiro</label>

                                <input type="date" class="form-control" id="withdrawal_date" name="withdrawal_date"
                                    placeholder="Ingrese el destino">


                                <?php $__errorArgs = ['withdrawal_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                        </div>

                        <div id="formConceptsTransport" class="formConcepts row">

                            <?php if(!isset($cost_transport)): ?>
                                <div class="col-4">

                                    <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'concept','id' => 'concept_transport','label' => 'Conceptos'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione un concepto...']); ?>
                                        <option />
                                        <?php $__currentLoopData = $concepts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($concept->typeService->name == 'Transporte' && $routing->type_shipment->id == $concept->id_type_shipment): ?>
                                                <option value="<?php echo e($concept->id); ?>"><?php echo e($concept->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>

                                </div>
                                <div class="col-4">
                                    <div class="form-group">
                                        <label for="value_concept">Valor del neto del concepto</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text text-bold">
                                                    $
                                                </span>
                                            </div>
                                            <input type="text" class="form-control CurrencyInput "
                                                name="value_concept" data-type="currency"
                                                placeholder="Ingrese valor del concepto" value="">
                                        </div>
                                    </div>

                                </div>

                                <div class="col-4">
                                    <div class="form-group">
                                        <label for="value_concept">Valor ha agregar</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text text-bold">
                                                    $
                                                </span>
                                            </div>
                                            <input type="text" class="form-control CurrencyInput "
                                                name="value_added" data-type="currency"
                                                placeholder="Ingrese valor agregado" value="0">
                                        </div>
                                    </div>

                                </div>
                                <div class="col-12 d-flex justify-content-center align-items-center pt-3 mb-2">
                                    <button class="btn btn-indigo" type="button" id="btnAddConcept"
                                        onclick="addConcept(this)">
                                        Agregar
                                    </button>

                                </div>
                            <?php endif; ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Concepto</th>
                                        <th>Valor del concepto</th>
                                        <th>Valor agregado</th>
                                        <th>Puntos Adicionales</th>
                                        <th>x</th>
                                    </tr>
                                </thead>
                                <tbody id="tbodyFlete">


                                </tbody>
                            </table>

                            <div class="row w-100 justify-content-end">

                                <div class="col-4 row">
                                    <label for="total" class="col-sm-4 col-form-label">Total:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="total" id="total"
                                            value="0.00" <?php if(true): echo 'readonly'; endif; ?>>
                                    </div>
                                </div>

                            </div>

                        </div>

                    </div>

                     <?php $__env->slot('footerSlot', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginal84b78d66d5203b43b9d8c22236838526 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84b78d66d5203b43b9d8c22236838526 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Button::resolve(['label' => 'Guardar','type' => 'submit'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-indigo','id' => 'btnSubmit','onclick' => 'submitForm(this)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $attributes = $__attributesOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__attributesOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $component = $__componentOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__componentOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal84b78d66d5203b43b9d8c22236838526 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84b78d66d5203b43b9d8c22236838526 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Button::resolve(['theme' => 'secondary','label' => 'cerrar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-dismiss' => 'modal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $attributes = $__attributesOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__attributesOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $component = $__componentOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__componentOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
                     <?php $__env->endSlot(); ?>
                </form>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2dfb698641700bc6575e0f9f2d3d632)): ?>
<?php $attributes = $__attributesOriginale2dfb698641700bc6575e0f9f2d3d632; ?>
<?php unset($__attributesOriginale2dfb698641700bc6575e0f9f2d3d632); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2dfb698641700bc6575e0f9f2d3d632)): ?>
<?php $component = $__componentOriginale2dfb698641700bc6575e0f9f2d3d632; ?>
<?php unset($__componentOriginale2dfb698641700bc6575e0f9f2d3d632); ?>
<?php endif; ?>


            
            <?php if (isset($component)) { $__componentOriginale2dfb698641700bc6575e0f9f2d3d632 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2dfb698641700bc6575e0f9f2d3d632 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Tool\Modal::resolve(['id' => 'modalSeguro','title' => 'Seguro','size' => 'lg','scrollable' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Tool\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'modal']); ?>

                <form action="/routing_insurance" method="POST" id="form_insurance">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="typeService" id="typeService">
                    <input type="hidden" name="service_insurance" id="service_insurance">
                    <input type="hidden" name="id_insurable_service" id="id_insurable_service">

                    <div class="row justify-content-center" id="content_seguro">
                        <div class="col-3">
                            <label for="type_insurance">Tipo de seguro</label>
                            <select name="type_insurance" class="form-control" label="Tipo de seguro"
                                igroup-size="md" data-placeholder="Seleccione una opcion...">
                                <option />
                                <?php $__currentLoopData = $type_insurace; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <label for="load_value">Valor del seguro</label>

                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-bold">
                                            $
                                        </span>
                                    </div>
                                    <input type="text" class="form-control CurrencyInput" name="value_insurance"
                                        data-type="currency" placeholder="Ingrese valor de la carga">
                                </div>

                            </div>
                        </div>

                        <div class="col-3">
                            <div class="form-group">
                                <label for="load_value">Valor ha agregar</label>

                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text text-bold">
                                            $
                                        </span>
                                    </div>
                                    <input type="text" class="form-control CurrencyInput" id="insurance_added"
                                        name="insurance_added" data-type="currency" value="0"
                                        placeholder="Ingrese valor de la carga"
                                        onchange="updateInsuranceAddedTotal(this)">
                                </div>

                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <label for="load_value">Puntos</label>

                                <div class="input-group">
                                    <input type="number" class="form-control" id="insurance_points"
                                        name="insurance_points" min="0"
                                        onkeydown="preventeDefaultAction(event)" oninput="addPointsInsurance(this)">
                                </div>

                            </div>
                        </div>
                    </div>

                     <?php $__env->slot('footerSlot', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginal84b78d66d5203b43b9d8c22236838526 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84b78d66d5203b43b9d8c22236838526 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Button::resolve(['label' => 'Guardar','type' => 'submit'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-indigo','id' => 'btnSubmit','onclick' => 'submitFormInsurance(this)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $attributes = $__attributesOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__attributesOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $component = $__componentOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__componentOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal84b78d66d5203b43b9d8c22236838526 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84b78d66d5203b43b9d8c22236838526 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Button::resolve(['theme' => 'secondary','label' => 'cerrar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-dismiss' => 'modal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $attributes = $__attributesOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__attributesOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $component = $__componentOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__componentOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
                     <?php $__env->endSlot(); ?>
                </form>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2dfb698641700bc6575e0f9f2d3d632)): ?>
<?php $attributes = $__attributesOriginale2dfb698641700bc6575e0f9f2d3d632; ?>
<?php unset($__attributesOriginale2dfb698641700bc6575e0f9f2d3d632); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2dfb698641700bc6575e0f9f2d3d632)): ?>
<?php $component = $__componentOriginale2dfb698641700bc6575e0f9f2d3d632; ?>
<?php unset($__componentOriginale2dfb698641700bc6575e0f9f2d3d632); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/routing/modals/modalsServices.blade.php ENDPATH**/ ?>