<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <h2>Actualizar un tipo de embarque</h2>
        <div>
            <button class="btn btn-primary"> Atras </button>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('dinamic-content'); ?>
    <form action=<?php echo e(url('/type_shipment/'. $type_shipment->id)); ?> method="POST" enctype="multipart/form-data">
        <?php echo e(method_field('PATCH')); ?>

        <?php echo e(csrf_field()); ?>

        <?php echo $__env->make('type_shipment.form-type_shipment', ['formMode' => 'edit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>

   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/type_shipment/edit-type_shipment.blade.php ENDPATH**/ ?>