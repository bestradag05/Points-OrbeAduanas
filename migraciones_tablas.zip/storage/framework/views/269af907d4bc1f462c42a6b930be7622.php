<div class="row">


    <div class="col-6">

        <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'id_document','label' => 'Tipo de documento','igroupSize' => 'md'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione una opcion...']); ?>
            <option />
            <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($document->id); ?>" 
                    <?php echo e((isset($customer->id_document) && $customer->id_document == $document->id) || old('id_document') == $document->id ? 'selected' : ''); ?>

                    >
                    <?php echo e($document->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>

    </div>

    <div class="col-6">
        <label for="document_number">Numero de documento</label>
        <div class="input-group">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-search"></i></span>
            </div>
            <input type="text" class="form-control" id="document_number" name="document_number" placeholder="Ingrese su numero de documento"
                onchange="searchsupplier(this)" value="<?php echo e(isset($customer->document_number) ? $customer->document_number : old('document_number')); ?>">

        </div>

        <?php $__errorArgs = ['document_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>

    <div class="col-6">

        <div class="form-group">
            <label for="name_businessname">Razon Social / Nombre</label>
            <input type="text" class="form-control" id="name_businessname" name="name_businessname"
                placeholder="Ingrese su razon social o nombre"
                value="<?php echo e(isset($customer->name_businessname) ? $customer->name_businessname : old('name_businessname')); ?>">
            <?php $__errorArgs = ['name_businessname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>


    <div class="col-6">

        <div class="form-group">
            <label for="address">Direccion</label>
            <input type="text" class="form-control" id="address" name="address"
                placeholder="Ingrese su razon social o nombre"
                value="<?php echo e(isset($customer->address) ? $customer->address : old('address')); ?>">
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>


    <div class="col-6">
        <div class="form-group">
            <label for="contact_name">Nombre del contacto</label>
            <input type="text" class="form-control" id="contact_name" name="contact_name"
                placeholder="Ingrese su numero de celular"
                value="<?php echo e(isset($customer->contact_name) ? $customer->contact_name : old('contact_name')); ?>">
            <?php $__errorArgs = ['contact_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>


    <div class="col-6">
        <div class="form-group">
            <label for="contact_number">Numero del contacto</label>
            <input type="text" class="form-control" id="contact_number" name="contact_number"
                placeholder="Ingrese su numero de celular"
                value="<?php echo e(isset($customer->contact_number) ? $customer->contact_number : old('contact_number')); ?>">
            <?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>


    <div class="col-6">

        <div class="form-group">
            <label for="contact_email">Correo del contacto</label>
            <input type="text" class="form-control" id="contact_email" name="contact_email"
                placeholder="Ingrese su numero de celular"
                value="<?php echo e(isset($customer->contact_email) ? $customer->contact_email : old('contact_email')); ?>">
            <?php $__errorArgs = ['contact_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>


    <div class="container text-center mt-5">
        <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Actualizar' : 'Guardar'); ?>">
    </div>



</div>


<?php $__env->startPush('scripts'); ?>
    <script>
        function searchsupplier(event) {

            const name_businessname = document.getElementById('name_businessname');

            fetch(`/obtener-datos-ruc/${event.value}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta de la red');
                    }
                    return response.json();
                })
                .then(data => {
                    // Manejar los datos de la respuesta

                    name_businessname.value = data.lista[0].apenomdenunciado;
                    name_businessname.readOnly  = true;
                   
                })
                .catch(error => {
                    // Manejar cualquier error
                    console.error('Hubo un problema con la solicitud fetch:', error);
            
                    name_businessname.value = '';
                    name_businessname.readOnly = false;
                });


        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/customer/form-customer.blade.php ENDPATH**/ ?>