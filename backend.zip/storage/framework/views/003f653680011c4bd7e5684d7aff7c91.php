<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <h2>Generar punto de aduana</h2>
        <div>
            <button class="btn btn-primary"> Atras </button>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('dinamic-content'); ?>



<form action=<?php echo e(url('/custom/' . $custom->id)); ?> method="POST" enctype="multipart/form-data">
    <?php echo e(method_field('PATCH')); ?>

    <?php echo e(csrf_field()); ?>

    <?php echo $__env->make('custom.form-point-custom', ['formMode' => 'edit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>


<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script>
        $('#reguralization').datetimepicker({
            format: 'DD/MM/YYYY',
            lang: 'es',
            mask: true,
            timepicker: false
            
            
        });

        $('#doc_custom').change(function() {
            var archivo = $(this).prop('files')[0];
            if (archivo) {
                // Por ejemplo, podrías enviar el formulario después de seleccionar el archivo

                $('#formLoadFile').submit();
            }
        });

    </script>


<?php $__env->stopPush(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/custom/edit-custom.blade.php ENDPATH**/ ?>