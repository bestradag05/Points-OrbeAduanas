<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Exportacion de Flete</title>
    <style>
         #tabla_freight {
            font-size: 12px;
            text-align: center;
            border-collapse: collapse;
         } 

       
         th, td {
            border: 1px solid black; /* Agrega bordes a las celdas */
            padding: 3px; /* Espaciado interno */
            text-align: center; /* Centra el texto */
        }

        #tabla_freight thead {
            background: #2e37a4;
            color: #fff;
        }

        #tabla_freight thead tr th{
            width: 58px;
        }
    </style>
</head>

<body>


    <table id="tabla_freight" class="table table-light">
        <thead class="thead-light">
            <tr>
                <th>#</th>
                <th>Roi</th>
                <th>Cliente</th>
                <th>Ruc</th>
                <th>Fecha</th>
                <th>Vendedor</th>
                <th>Tipo de Embarque</th>
                <th>Regimen</th>
                <th>HAWB / HBL</th>
                <th>BL a trabajar</th>
                <th>ETD</th>
                <th>ETA</th>
                <th>Origen - Destino</th>
                <th>Utilidad Orbe</th>
                <th>Flete Orbe</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $freights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $freight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($freight->roi); ?></td>
                    <td><?php echo e($freight->routing->customer->name_businessname); ?></td>
                    <td><?php echo e($freight->routing->customer->document_number); ?></td>
                    <td><?php echo e($freight->date_register); ?></td>
                    <td><?php echo e($freight->routing->personal->names); ?></td>
                    <td><?php echo e($freight->routing->type_shipment->code); ?></td>
                    <td><?php echo e($freight->routing->regime->code); ?></td>
                    <td><?php echo e($freight->hawb_hbl); ?></td>
                    <td><?php echo e($freight->bl_work); ?></td>
                    <td><?php echo e($freight->edt); ?></td>
                    <td><?php echo e($freight->eta); ?></td>
                    <td><?php echo e($freight->routing->origin .' / '. $freight->routing->destination); ?></td>
                    <td><?php echo e($freight->value_utility); ?></td>
                    <td><?php echo e($freight->value_freight); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>

</body>

</html>
<?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/points/exports/freight/freight-export.blade.php ENDPATH**/ ?>