<div class="row">

    <div class="col-6">

        <div class="form-group">
            <label for="name">Nombre de documento</label>
            <input type="text" class="form-control" id="name" name="name"
                placeholder="Ingrese el nombre del documento "
                value="<?php echo e(isset($personal_document->name) ? $personal_document->name : old('name')); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>



    <div class="col-6">

        <div class="form-group">
            <label for="number_digits">Numero de digitos</label>
            <input type="text" class="form-control" id="number_digits" name="number_digits"
                placeholder="Ingrese el numero de digitos"
                value="<?php echo e(isset($personal_document->number_digits) ? $personal_document->number_digits : old('number_digits')); ?>">
            <?php $__errorArgs = ['number_digits'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>


    <div class="container text-center mt-5">
        <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Actualizar' : 'Guardar'); ?>">
    </div>



</div>


<?php $__env->startPush('scripts'); ?>
    <script>
        function searchCustomer(event) {

            const name_businessname = document.getElementById('name_businessname');

            fetch(`/obtener-datos-ruc/${event.value}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta de la red');
                    }
                    return response.json();
                })
                .then(data => {
                    // Manejar los datos de la respuesta

                    name_businessname.value = data.lista[0].apenomdenunciado;
                    name_businessname.readOnly  = true;
                   
                })
                .catch(error => {
                    // Manejar cualquier error
                    console.error('Hubo un problema con la solicitud fetch:', error);
            
                    name_businessname.value = '';
                    name_businessname.readOnly = false;
                });


        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/personal_documents/form-personal-document.blade.php ENDPATH**/ ?>