<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Exportacion de transporte</title>
    <style>
         #tabla_transport {
            font-size: 12px;
            text-align: center;
            border-collapse: collapse;
         } 

       
         th, td {
            border: 1px solid black; /* Agrega bordes a las celdas */
            padding: 3px; /* Espaciado interno */
            text-align: center; /* Centra el texto */
        }

        #tabla_transport thead {
            background: #2e37a4;
            color: #fff;
        }

        #tabla_transport thead tr th{
            width: 55px;
        }
    </style>
</head>

<body>


    <table id="tabla_transport" class="table table-light">
        <thead class="thead-light">
            <tr>
                <th>#</th>
                <th>Fecha</th>
                <th>N° Factura</th>
                <th>Proveedor</th>
                <th>Cliente</th>
                <th>Ruc</th>
                <th>Numero de Orden</th>
                <th>Numero de Dua</th>
                <th>Direccion</th>
                
                <th>Base Imponible</th>
                <th>IGV</th>
                <th>Total</th>
                <th>Estado de pago</th>
                <th>Fecha de pago</th>
                <th>Vendedor</th>
                <th>Peso</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($transport->date_register); ?></td>
                    <td><?php echo e($transport->invoice_number); ?></td>
                    <td><?php echo e($transport->routing->supplier->name_businessname); ?></td>
                    <td><?php echo e($transport->routing->customer->name_businessname); ?></td>
                    <td><?php echo e($transport->routing->customer->document_number); ?></td>
                    <td><?php echo e($transport->nro_orden); ?></td>
                    <td><?php echo e($transport->nro_dua); ?></td>
                    <td><?php echo e($transport->origin . ' - ' . $transport->destination); ?></td>
                    <td><?php echo e($transport->tax_base); ?></td>
                    <td><?php echo e($transport->igv); ?></td>
                    <td><?php echo e($transport->total); ?></td>
                    <td><?php echo e($transport->payment_state); ?></td>
                    <td><?php echo e($transport->payment_date); ?></td>
                    <td><?php echo e($transport->routing->personal->names); ?></td>
                    <td><?php echo e($transport->weight); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>

</body>

</html>
<?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/points/exports/transport/transport-export.blade.php ENDPATH**/ ?>