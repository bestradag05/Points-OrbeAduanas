  <div id="test-l-1" role="tabpanel" class="bs-stepper-pane active dstepper-block" aria-labelledby="stepper1trigger1">
      <div class="form-group">
          <label for="nro_operation">N° de operacion</label>
          <input type="text" class="form-control" id="nro_operation" name="nro_operation"
              placeholder="Ingrese el numero de operacion" <?php if(true): echo 'readonly'; endif; ?>
              value="<?php echo e(isset($routing->nro_operation) ? $routing->nro_operation : $nro_operation); ?>">
          <?php $__errorArgs = ['nro_operation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="row">

          <div class="col-6">

              <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'origin','label' => 'Origen','igroupSize' => 'md'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione una opcion...']); ?>
                  <option />
                  <?php $__currentLoopData = $stateCountrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stateCountry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option
                          <?php echo e((isset($routing->origin) && $routing->origin == $stateCountry->country->name . ' - ' . $stateCountry->name) || old('origin') == $stateCountry->country->name . ' - ' . $stateCountry->name ? 'selected' : ''); ?>>
                          <?php echo e($stateCountry->country->name . ' - ' . $stateCountry->name); ?>

                      </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>

          </div>
          <div class="col-6">

              <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'destination','label' => 'Destino','igroupSize' => 'md'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione una opcion...']); ?>
                  <option />
                  <?php $__currentLoopData = $stateCountrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stateCountry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option
                          <?php echo e((isset($routing->destination) && $routing->destination == $stateCountry->country->name . ' - ' . $stateCountry->name) || old('destination') == $stateCountry->country->name . ' - ' . $stateCountry->name ? 'selected' : ''); ?>>
                          <?php echo e($stateCountry->country->name . ' - ' . $stateCountry->name); ?>

                      </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>

          </div>



          <div class="col-6">

              <div class="form-group">
                  <label for="load_value">Valor del la carga</label>

                  <div class="input-group">
                      <div class="input-group-prepend">
                          <span class="input-group-text text-bold <?php $__errorArgs = ['load_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                              $
                          </span>
                      </div>
                      <input type="text"
                          class="form-control CurrencyInput <?php $__errorArgs = ['load_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                          name="load_value" data-type="currency" placeholder="Ingrese valor de la carga"
                          value="<?php echo e(isset($routing->load_value) ? $routing->load_value : old('load_value')); ?>">
                  </div>
                  <?php $__errorArgs = ['load_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback d-block" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

              </div>
          </div>


          <div class="col-6">
              <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'id_customer','label' => 'Clientes','igroupSize' => 'md'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione una opcion...']); ?>
                  <option />
                  <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($customer->id); ?>"
                          <?php echo e((isset($routing->id_customer) && $routing->id_customer == $customer->id) || old('id_customer') == $customer->id ? 'selected' : ''); ?>>
                          <?php echo e($customer->name_businessname); ?>

                      </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
          </div>

          <div class="col-6">
              <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'id_supplier','label' => 'Provedor del Cliente','igroupSize' => 'md'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione una opcion...']); ?>
                  <option />
                  <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($supplier->id); ?>"
                          <?php echo e((isset($routing->id_supplier) && $routing->id_supplier == $supplier->id) || old('id_supplier') == $supplier->id ? 'selected' : ''); ?>>
                          <?php echo e($supplier->name_businessname); ?>

                      </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
          </div>

          <div class="col-6 row" id="lclfcl_content">
              <div class="col-12">
                  <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'id_type_shipment','label' => 'Tipo de embarque','igroupSize' => 'md'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione una opcion...']); ?>
                      <option />
                      <?php $__currentLoopData = $type_shipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($type_shipment->id); ?>"
                              <?php echo e((isset($routing->id_type_shipment) && $routing->id_type_shipment == $type_shipment->id) || old('id_type_shipment') == $type_shipment->id ? 'selected' : ''); ?>>
                              <?php echo e($type_shipment->code . ' - ' . $type_shipment->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>

              </div>
              <div id="contenedor_radio_lcl_fcl" class="col-4 d-none align-items-center">
                  <div class="form-check d-inline">
                      <input type="radio" id="radioLcl" name="lcl_fcl" value="LCL"
                          <?php echo e((isset($routing->lcl_fcl) && $routing->lcl_fcl === 'LCL') || old('lcl_fcl') === 'LCL' ? 'checked' : ''); ?>

                          class="form-check-input <?php $__errorArgs = ['lcl_fcl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                      <label for="radioLclFcl" class="form-check-label">
                          LCL
                      </label>
                  </div>
                  <div class="form-check d-inline">
                      <input type="radio" id="radioFcl" name="lcl_fcl" value="FCL"
                          <?php echo e((isset($routing->lcl_fcl) && $routing->lcl_fcl === 'FCL') || old('lcl_fcl') === 'FCL' ? 'checked' : ''); ?>

                          class="form-check-input <?php $__errorArgs = ['lcl_fcl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                      <label for="radioLclFcl" class="form-check-label">
                          FCL
                      </label>
                  </div>
              </div>

          </div>

          <div class="col-6">
              <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'id_type_load','label' => 'Tipo de carga','igroupSize' => 'md'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione una opcion...']); ?>
                  <option />
                  <?php $__currentLoopData = $type_loads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_load): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($type_load->id); ?>"
                          <?php echo e((isset($routing->id_type_load) && $routing->id_type_load == $type_load->id) || old('id_type_load') == $type_load->id ? 'selected' : ''); ?>>
                          <?php echo e($type_load->name); ?>

                      </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
          </div>

          <div class="col-6">
              <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'id_regime','label' => 'Regimen','igroupSize' => 'md'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione una opcion...']); ?>
                  <option />
                  <?php $__currentLoopData = $regimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($regime->id); ?>"
                          <?php echo e((isset($routing->id_regime) && $routing->id_regime == $regime->id) || old('id_regime') == $regime->id ? 'selected' : ''); ?>>
                          <?php echo e($regime->code . ' - ( ' . $regime->description . ' )'); ?>

                      </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
          </div>

          <div class="col-6">
              <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['name' => 'id_incoterms','label' => 'Incoterms','igroupSize' => 'md'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione una opcion...']); ?>
                  <option />
                  <?php $__currentLoopData = $incoterms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incoter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($incoter->id); ?>"
                          <?php echo e((isset($routing->id_incoterms) && $routing->id_incoterms == $incoter->id) || old('id_incoterms') == $incoter->id ? 'selected' : ''); ?>>
                          <?php echo e($incoter->code); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $attributes = $__attributesOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__attributesOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
          </div>

          <div class="col-12 mb-5">
              <label for="wr_loading" class="bg-indigo w-100 px-2 py-1"> WR Loading </label>
              <div class="form-group row justify-content-center">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">WR Loading:</label>
                  <div class="col-sm-6">
                      <input type="text" class="form-control" id="wr_loading" name="wr_loading"
                          placeholder="Ingrese su WR..."
                          value="<?php echo e(isset($routing->wr_loading) ? $routing->wr_loading : old('wr_loading')); ?>">
                  </div>
              </div>
          </div>

      </div>

      <button class="btn btn-primary" onclick="stepper.next()">Siguiente</button>
  </div>
  <div id="test-l-2" role="tabpanel" class="bs-stepper-pane" aria-labelledby="stepper1trigger2">

      <div class="form-group row">
          <label for="commodity" class="col-sm-2 col-form-label">Producto</label>
          <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['commodity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="commodity"
                  name="commodity" placeholder="Ingrese el producto.."
                  value="<?php echo e(isset($routing->commodity) ? $routing->commodity : old('commodity')); ?>">
              <?php $__errorArgs = ['commodity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback d-block" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
      </div>

      <div class="row">

          <div class="col-6">
              <div class="form-group row">
                  <label for="nro_package" class="col-sm-4 col-form-label">N° Paquetes</label>
                  <div class="col-sm-8">
                      <input type="number" min="0" step="1"
                          class="form-control <?php $__errorArgs = ['nro_package'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nro_package"
                          name="nro_package" placeholder="Ingrese el nro de paquetes.."
                          oninput="validarInputNumber(this)" onchange="cleanMeasures()"
                          value="<?php echo e(isset($routing) ? $routing->nro_package : ''); ?>">
                      <?php $__errorArgs = ['nro_package'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="invalid-feedback d-block" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>

          </div>

          <div class="col-6">
              <div class="form-group row">
                  <label for="packaging_type" class="col-sm-4 col-form-label">Tipo de embalaje</label>
                  <div class="col-sm-8">
                      <input type="text" min="0" step="1"
                          class="form-control <?php $__errorArgs = ['packaging_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="packaging_type"
                          name="packaging_type" placeholder="Ingrese el tipo de embalaje.."
                          value="<?php echo e(isset($routing) ? $routing->packaging_type : ''); ?>">
                      <?php $__errorArgs = ['packaging_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="invalid-feedback d-block" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>
          </div>

          <div class="col-4 d-none" id="containerTypeWrapper">
              <div class="form-group row">
                  <label for="container_type" class="col-sm-4 col-form-label">Tipo de contenedor</label>
                  <div class="col-sm-8">
                      <input type="text" min="0" step="1"
                          class="form-control <?php $__errorArgs = ['container_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="container_type"
                          name="container_type" placeholder="Ingrese el tipo de contenedor.."
                          value="<?php echo e(isset($routing) ? $routing->container_type : old('container_type')); ?>">
                      <?php $__errorArgs = ['container_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="invalid-feedback d-block" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>
          </div>
          <div class="col-12">

              <div id="div_measures" class="row justify-content-center">

                  <div class="col-2">
                      <input type="number" class="form-control" step="1" id="amount_package"
                          name="amount_package" placeholder="Ingresa la cantidad">
                  </div>
                  <div class="col-2">
                      <input type="text" class="form-control CurrencyInput" data-type="currency" id="width"
                          name="width" placeholder="Ancho(cm)">
                  </div>
                  <div class="col-2">
                      <input type="text" class="form-control CurrencyInput" data-type="currency" id="length"
                          name="length" placeholder="Largo(cm)">
                  </div>
                  <div class="col-2">
                      <input type="text" class="form-control CurrencyInput" data-type="currency" id="height"
                          name="height" placeholder="Alto(cm)">
                  </div>
                  <div class="col-2">
                      <button id="addRow" class="btn btn-indigo btn-sm"><i class="fa fa-plus"></i>Agregar</button>
                  </div>

              </div>

              <table id="measures" class="table table-bordered" style="width:100%">
                  <thead>
                      <tr>
                          <th>Cantidad</th>
                          <th>Ancho (cm)</th>
                          <th>Largo (cm)</th>
                          <th>Alto (cm)</th>
                          <th>Eliminar</th>
                      </tr>
                  </thead>
                  

              </table>
              <input id="value_measures" type="hidden" name="value_measures" />
              <?php $__errorArgs = ['value_measures'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback d-block" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

          </div>
      </div>


      <div class="row">
          <label for="total_gross_weight" class="w-100">Total peso bruto</label>
          <hr class="w-100">

          <div class="col-4">
              <div class="form-group row">
                  <label for="pounds" class="col-sm-4 col-form-label">Libras: </label>
                  <div class="col-sm-8">
                      <input type="text" class="form-control CurrencyInput" id="pounds" name="pounds"
                          data-type="currency" placeholder="Ingrese las libras"
                          value="<?php echo e(isset($routing) ? $routing->pounds : ''); ?>" <?php if(true): echo 'readonly'; endif; ?>>
                      <?php $__errorArgs = ['pounds'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="text-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>
          </div>

          <div class="col-4">
              <div id="contenedor_weight" class="form-group row d-none">
                  <label for="kilograms" class="col-sm-4 col-form-label">Peso Total : </label>
                  <div class="col-sm-8">
                      <input type="text"
                          class="form-control CurrencyInput <?php $__errorArgs = ['kilograms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kilograms"
                          name="kilograms" data-type="currency" placeholder="Ingrese el peso.."
                          value="<?php echo e(isset($routing->kilograms) ? $routing->kilograms : old('kilograms')); ?>">
                      <?php $__errorArgs = ['kilograms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="invalid-feedback d-block" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>

              <div id="contenedor_tons" class="form-group row d-none">
                  <label for="tons" class="col-sm-4 col-form-label">Toneladas : </label>
                  <div class="col-sm-8">
                      <input type="text" class="form-control CurrencyInput <?php $__errorArgs = ['tons'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                          id="tons" name="tons" data-type="currency"
                          placeholder="Ingrese el nro de paquetes.."
                          value="<?php echo e(isset($routing->tons) ? $routing->tons : old('tons')); ?>">
                  </div>
                  <?php $__errorArgs = ['tons'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback d-block" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

          </div>


          <div class="col-4">
              <div id="contenedor_volumen" class="form-group row  d-none">
                  <label for="volumen" class="col-sm-4 col-form-label">Volumen: </label>
                  <div class="col-sm-8">
                      
                      <input type="text" class="form-control CurrencyInput <?php $__errorArgs = ['volumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                          id="volumen" name="volumen" data-type="currency"
                          placeholder="Ingrese el nro de paquetes.."
                          value="<?php echo e(isset($routing->volumen) ? $routing->volumen : old('volumen')); ?>">
                  </div>

                  <?php $__errorArgs = ['volumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback d-block" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div id="contenedor_kg_vol" class="form-group row d-none">
                  <label for="volumen" class="col-sm-4 col-form-label">Kg/vol: </label>
                  <div class="col-sm-8">
                      

                      <input type="text"
                          class="form-control CurrencyInput <?php $__errorArgs = ['kilogram_volumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                          id="kilogram_volumen" name="kilogram_volumen" data-type="currency"
                          placeholder="Ingrese el nro de paquetes.."
                          value="<?php echo e(isset($routing->kilogram_volumen) ? $routing->kilogram_volumen : old('kilogram_volumen')); ?>">
                  </div>
                  <?php $__errorArgs = ['kilogram_volumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback d-block" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

          </div>
      </div>
      <hr class="w-100">
      <div class="form-group row">
          <label for="hs_code" class="col-sm-2 col-form-label">H.S. Code</label>
          <div class="col-sm-10">
              <input type="number" min="0" step="1" class="form-control" id="hs_code"
                  name="hs_code" placeholder="Ingrese el hs code.." oninput="validarInputNumber(this)"
                  value="<?php echo e(isset($routing) ? $routing->hs_code : ''); ?>">
              <?php $__errorArgs = ['hs_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
      </div>

      <div class="form-group row">
          <label for="observation" class="col-sm-2 col-form-label">Observacion</label>
          <div class="col-sm-10">
              <textarea name="observation" id="observation" class="form-control" cols="30" rows="5"><?php echo e(isset($routing->observation) ? $routing->observation : old('observation')); ?></textarea>
              <?php $__errorArgs = ['observation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
      </div>

      <input type="hidden" id="type_shipment_name" name="type_shipment_name">



      <button class="btn btn-secondary mt-5" onclick="stepper.previous()">Anterior</button>
      <button type="submit" class="btn btn-indigo mt-5" onclick="submitForm()">Guardar</button>
  </div>


  <?php $__env->startPush('scripts'); ?>
      <script>
          const dataMeasures = <?php echo json_encode(isset($routing->measures) ? $routing->measures : '', 15, 512) ?>;
          document.addEventListener('DOMContentLoaded', function() {



              // Obtener los valores de los campos del formulario (puedes personalizar esto para tu caso)
              let volumenValue = document.getElementById('volumen');
              let kilogramoVolumenValue = document.getElementById('kilogram_volumen');
              let toneladasValue = document.getElementById('tons');
              let totalWeight = document.getElementById('kilograms');
              let lcl_fcl = document.getElementsByName('lcl_fcl');
              let container_type = document.getElementById('container_type');

              // Mostrar/ocultar los campos según los valores
              if (volumenValue.value !== '' || volumenValue.classList.contains('is-invalid')) {
                  document.getElementById('contenedor_volumen').classList.remove('d-none');
              }

              if (kilogramoVolumenValue.value !== '' || kilogramoVolumenValue.classList.contains('is-invalid')) {
                  document.getElementById('contenedor_kg_vol').classList.remove('d-none');

              }

              if (totalWeight.value !== '' || totalWeight.classList.contains('is-invalid')) {
                  document.getElementById('contenedor_weight').classList.remove('d-none');

              }

              if (toneladasValue.value !== '' || toneladasValue.classList.contains('is-invalid')) {
                  document.getElementById('contenedor_tons').classList.remove('d-none');

              }

              if (container_type.value !== '' || container_type.classList.contains('is-invalid')) {
                  document.getElementById('containerTypeWrapper').classList.remove('d-none');

                  const parentElement = document.getElementById('containerTypeWrapper').closest('.row');

                  if (parentElement) {
                      const firstChild = parentElement.children[0]; // Primer hijo
                      const secondChild = parentElement.children[1]; // Segundo hijo

                      // Añade la clase 'col-6' a los dos primeros hijos
                      if (firstChild) {
                          firstChild.classList.add('col-4');
                          firstChild.classList.remove('col-6');
                      }
                      if (secondChild) {

                          secondChild.classList.add('col-4');
                          secondChild.classList.remove('col-6')

                      }
                  }

              }

              let isChecked = Array.from(lcl_fcl).some(radio => radio.checked);
              let hasInvalidClass = Array.from(lcl_fcl).some(radio => radio.classList.contains('is-invalid'));


              if (isChecked || hasInvalidClass) {
                  $('#lclfcl_content').children().first().removeClass('col-12').addClass('col-8');
                  $('#lclfcl_content').children().last().removeClass('d-none').addClass('d-flex');
                  document.getElementById('contenedor_radio_lcl_fcl').classList.remove('d-none');
              }
          })

          $('#id_type_shipment').on('change', (e) => {

              var idShipment = $(e.target).find("option:selected").val();

              $.ajax({
                  type: "GET",
                  url: "/getLCLFCL",
                  data: {
                      idShipment
                  },
                  dataType: "JSON",
                  success: function(respu) {
                      if (respu.description === "Marítima") {

                          $('#type_shipment_name').val(respu.description);

                          $('#lclfcl_content').children().first().removeClass('col-12').addClass('col-8');
                          $('#lclfcl_content').children().last().removeClass('d-none').addClass('d-flex');

                          $('#contenedor_volumen').removeClass('d-none');
                          $('#contenedor_kg_vol').addClass('d-none');

                          $('#contenedor_volumen').find('input').val("");
                          $('#contenedor_kg_vol').find('input').val("");




                      } else {


                          $('#type_shipment_name').val(respu.description);

                          $('#lclfcl_content').children().first().removeClass('col-8').addClass('col-12');
                          $('#lclfcl_content').children().last().removeClass('d-flex').addClass('d-none');
                          $('input[name="lcl_fcl"]').prop('checked', false);

                          $('#contenedor_volumen').addClass('d-none');
                          $('#contenedor_kg_vol').removeClass('d-none');

                          $('#contenedor_kg_vol').find('input').val("");
                          $('#contenedor_volumen').find('input').val("");

                          $('#containerTypeWrapper').find('input').val("");
                          $('#containerTypeWrapper').addClass('d-none');

                          const parentElement = document.getElementById('containerTypeWrapper').closest(
                              '.row');

                          if (parentElement) {
                              const firstChild = parentElement.children[0]; // Primer hijo
                              const secondChild = parentElement.children[1]; // Segundo hijo

                              // Añade la clase 'col-6' a los dos primeros hijos
                              if (firstChild) {
                                  firstChild.classList.add('col-6');
                                  firstChild.classList.remove('col-4');
                              }
                              if (secondChild) {

                                  secondChild.classList.add('col-6');
                                  secondChild.classList.remove('col-4')

                              }
                          }


                          $('#contenedor_tons').find('input').val("");
                          $('#contenedor_tons').addClass('d-none');
                          $('#contenedor_weight').removeClass('d-none');



                      }
                  }
              });


          });

          $('#kilograms').on('change', (e) => {

              let kilogramsVal = $(e.target).val();
              let kilograms = kilogramsVal.replace(/,/g, '');
              let numberValue = parseFloat(kilograms);

              if (!kilogramsVal || isNaN(numberValue)) {

                  $('#pounds').val(0);

              } else {

                  $('#pounds').val(numberValue * 2.21);

              }


          });


          //Inicializamos la tabla de medidas

          const table = new DataTable('#measures', {
              paging: false, // Desactiva la paginación
              searching: false, // Oculta el cuadro de búsqueda
              info: false, // Oculta la información del estado de la tabla
              lengthChange: false, // Oculta el selector de cantidad de registros por página
              language: { // Traducciones al español
                  emptyTable: "No hay medidas registradas"
              }
          });
          let counter = 1;

          // Función para agregar una fila editable
          let rowIndex = 1; //
          let currentPackage = 0;
          let arrayMeasures = {};


          if (dataMeasures != "") {

              const measuresObject = JSON.parse(dataMeasures);

              Object.entries(measuresObject).forEach(([key, item], index) => {

                  const newRow = table.row.add([
                      `<input type="number" class="form-control" readonly id="amount-${index}" name="amount-${index}" value="${item.amount}" placeholder="Cantidad" min="0" step="1">`,
                      `<input type="number" class="form-control" readonly id="width-${index}" name="width-${index}" value="${item.width}" placeholder="Ancho" min="0" step="0.0001">`,
                      `<input type="number" class="form-control" readonly id="length-${index}" name="length-${index}" value="${item.length}" placeholder="Largo" min="0" step="0.0001">`,
                      `<input type="number" class="form-control" readonly id="height-${index}" name="height-${index}" value="${item.height}" placeholder="Alto" min="0" step="0.0001">`,
                      `<button type="button" class="btn btn-danger btn-sm" id="delete-${index}" onclick="deleteRow('row-${index}', ${item.amount}, ${index})"><i class="fa fa-trash"></i></button>`
                  ]).draw().node();
                  newRow.id = `row-${index}`;

                  // Guardamos las medidas en el objeto `arrayMeasures`
                  arrayMeasures[index] = {
                      amount: item.amount,
                      width: item.width,
                      length: item.length,
                      height: item.height
                  };

                  currentPackage += item.amount; // Sumar al total de paquetes ya cargados
              });

              $('#value_measures').val(JSON.stringify(arrayMeasures));

          }



          document.getElementById('addRow').addEventListener('click', () => {

              var measures = document.getElementById("div_measures");
              const inputs = measures.querySelectorAll('input');

              let isValid = true;
              inputs.forEach(input => {

                  if (input.value.trim() === '' || input.value <= 0) {
                      isValid = false;
                      input.classList.add('is-invalid');
                      return;
                  } else {
                      input.classList.remove('is-invalid');
                      return;
                  }

              });

              if (!isValid) {
                  return;
              }

              const nro_package = parseInt($('#nro_package').val());
              const amount_package = parseInt($('#amount_package').val());
              const width = inputs[1].value;
              const length = inputs[2].value;
              const height = inputs[3].value;




              if (isNaN(amount_package) || amount_package <= 0) {
                  $('#amount_package').addClass('is-invalid');
                  return;
              } else {
                  if (isNaN(nro_package) || amount_package > nro_package) {
                      alert(
                          'El numero de paquetes / bultos no puede ser menor que la cantidad ingresada'
                      );
                      return;
                  }

                  currentPackage += amount_package;


                  if (currentPackage > nro_package) {
                      alert(
                          'No se puede agregar otra fila, por que segun los registros ya completaste el numero de bultos'
                      );
                      currentPackage -= amount_package;
                      return;
                  }

                  const newRow = table.row.add([

                      // Campo para Cantidad
                      `<input type="number" class="form-control"  readonly id="amount-${rowIndex}" name="amount-${rowIndex}" value="${amount_package}" placeholder="Cantidad" min="0" step="1">`,

                      // Campo para Ancho
                      `<input type="number" class="form-control"  readonly id="width-${rowIndex}" name="width-${rowIndex}" value="${width}" placeholder="Ancho" min="0" step="0.0001">`,

                      // Campo para Largo
                      `<input type="number" class="form-control"  readonly id="length-${rowIndex}" name="length-${rowIndex}" value="${length}" placeholder="Largo" min="0" step="0.0001">`,

                      // Campo para Alto
                      `<input type="number" class="form-control"  readonly id="height-${rowIndex}" name="height-${rowIndex}" value="${height}" placeholder="Alto" min="0" step="0.0001">`,

                      `<button type="button" class="btn btn-danger btn-sm" id="delete-${rowIndex}" onclick="deleteRow('row-${rowIndex}', ${amount_package}, ${rowIndex})"><i class="fa fa-trash"></i></button>`
                  ]).draw().node();
                  newRow.id = `row-${rowIndex}`;

                  arrayMeasures[rowIndex] = { // Usamos rowIndex como clave
                      amount: amount_package,
                      width,
                      length,
                      height
                  };


                  $('#value_measures').val(JSON.stringify(arrayMeasures));

                  rowIndex++

                  // Opcional: Enfocar el primer campo de la nueva fila
                  newRow.querySelector('input').focus();

              }

          });


          function deleteRow(rowId, amount, index) {
              // Reducir el paquete actual
              currentPackage -= parseInt(amount);
              // Eliminar la fila del DataTable
              const row = document.getElementById(rowId);
              table.row($(row).closest('tr')).remove().draw();
              delete arrayMeasures[index];
              $('#value_measures').val(JSON.stringify(arrayMeasures));

          }

          function cleanMeasures() {
              table.clear().draw();

              arrayMeasures = {};
              $('#value_measures').val("");

              // Restablecer variables relacionadas
              currentPackage = 0;
              rowIndex = 1;

          }


          document.querySelectorAll('input[name="lcl_fcl"]').forEach(radio => {
              radio.addEventListener('change', function() {
                  const containerTypeWrapper = document.getElementById('containerTypeWrapper');
                  const contenedor_tons = document.getElementById('contenedor_tons');
                  const contenedor_weight = document.getElementById('contenedor_weight');

                  // Si el valor es FCL, mostrar el campo
                  if (this.value === 'FCL') {
                      containerTypeWrapper.classList.remove('d-none');
                      contenedor_tons.classList.remove('d-none');
                      contenedor_weight.classList.add('d-none');

                      const parentElement = containerTypeWrapper.closest('.row');
                      if (parentElement) {
                          const firstChild = parentElement.children[0]; // Primer hijo
                          const secondChild = parentElement.children[1]; // Segundo hijo

                          // Añade la clase 'col-6' a los dos primeros hijos
                          if (firstChild) {
                              firstChild.classList.add('col-4');
                              firstChild.classList.remove('col-6');
                          }
                          if (secondChild) {

                              secondChild.classList.add('col-4');
                              secondChild.classList.remove('col-6')

                          }
                      }

                  } else {
                      // Si no es FCL, ocultar el campo
                      containerTypeWrapper.classList.add('d-none');
                      contenedor_tons.classList.add('d-none');
                      contenedor_weight.classList.remove('d-none');

                      $('#containerTypeWrapper').find('input').val('');

                      const parentElement = containerTypeWrapper.closest('.row');
                      if (parentElement) {
                          const firstChild = parentElement.children[0]; // Primer hijo
                          const secondChild = parentElement.children[1]; // Segundo hijo

                          // Añade la clase 'col-6' a los dos primeros hijos
                          if (firstChild) {
                              firstChild.classList.add('col-6');
                              firstChild.classList.remove('col-4');
                          }
                          if (secondChild) {

                              secondChild.classList.add('col-6');
                              secondChild.classList.remove('col-4')

                          }
                      }

                  }
              });
          });
      </script>


      


      <script>
          document.addEventListener("DOMContentLoaded", (event) => {

              var form = document.getElementById('formRouting');

              if (form.querySelectorAll(".is-invalid").length > 0) {

                  var invalidInputs = form.querySelectorAll(".is-invalid");
                  if (form.querySelectorAll(".is-invalid")) {
                      // Encuentra el contenedor del paso que contiene el campo de entrada inválido
                      var stepContainer = invalidInputs[0].parentNode.parentNode.closest('.bs-stepper-pane')
                      /*  console.log(invalidInputs[0].parentNode.parentNode.closest('.bs-stepper-pane')); */

                      // Encuentra el índice del paso correspondiente
                      var stepIndex = Array.from(stepContainer.parentElement.children).indexOf(stepContainer);

                      // Cambia el stepper al paso correspondiente
                      stepper.to(stepIndex);

                      // Enfoca el primer campo de entrada inválido
                      invalidInputs[0].focus();
                  }


              }
          });


          var stepper1Node = document.querySelector('#stepper');
          var stepper = new Stepper(document.querySelector('#stepper'));


          function submitForm() {
              var form = document.getElementById('formRouting');


              if (form.checkValidity()) {
                  // Aquí puedes enviar el formulario si la validación pasa
                  form.submit();
              } else {


                  var invalidInputs = form.querySelectorAll(":invalid");
                  if (form.querySelectorAll("invalid")) {
                      // Encuentra el contenedor del paso que contiene el campo de entrada inválido
                      var stepContainer = invalidInputs[0].closest('.content');

                      // Encuentra el índice del paso correspondiente
                      var stepIndex = Array.from(stepContainer.parentElement.children).indexOf(stepContainer);

                      // Cambia el stepper al paso correspondiente
                      stepper.to(stepIndex);

                      // Enfoca el primer campo de entrada inválido
                      invalidInputs[0].focus();
                  }
              }
          }


          function validarInputNumber(input) {
              if (input.value < 0) {
                  input.value = '';
              }
          }
      </script>
  <?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/routing/form-routing.blade.php ENDPATH**/ ?>