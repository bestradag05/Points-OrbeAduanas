<div class="row">
    


    <div class="col-6">
        <div class="form-group">
            <label for="names">Nombre</label>
            <input type="text" class="form-control" id="names" name="names" placeholder="Ingrese su nombre"
                value="<?php echo e(isset($personal->names) ? $personal->names : old('names')); ?>">
            <?php $__errorArgs = ['names'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>

    <div class="col-6">
        <div class="form-group">
            <label for="last_name">Apellido Paterno</label>
            <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Ingrese su apellido"
                value="<?php echo e(isset($personal->last_name) ? $personal->last_name : old('last_name')); ?>">
            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-6">
        <div class="form-group">
            <label for="mother_last_name">Apellido Materno</label>
            <input type="text" class="form-control" id="mother_last_name" name="mother_last_name"
                placeholder="Ingrese su apellido"
                value="<?php echo e(isset($personal->mother_last_name) ? $personal->mother_last_name : old('mother_last_name')); ?>">
            <?php $__errorArgs = ['mother_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-6">

        <div id="contain_select" class="form-group">
            <label for="id_document">Documento de identidad</label>
            <select name="id_document" id="id_document" class="form-control">
                <option value="" disabled selected> -- Seleccione --</option>
                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($document->id); ?>" 
                        <?php echo e((isset($personal->id_document) && $personal->id_document == $document->id) || old('id_document') == $document->id ? 'selected' : ''); ?>

                        >
                        <?php echo e($document->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


    </div>

    <div class="col-6">

        <div class="form-group">
            <label for="document_number">N° de documento</label>
            <input type="text" class="form-control" id="document_number" name="document_number"
                placeholder="Ingrese su apellido"
                value="<?php echo e(isset($personal->document_number) ? $personal->document_number : old('document_number')); ?>">
            <?php $__errorArgs = ['document_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>


    <div class="col-6">
        <?php
            $config = ['format' => 'L'];
        ?>
        <?php if (isset($component)) { $__componentOriginalc8dc1514386dad8f66b5b18640b397fe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8dc1514386dad8f66b5b18640b397fe = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\InputDate::resolve(['name' => 'birthdate','label' => 'Fecha de nacimiento','config' => $config] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-input-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\InputDate::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(isset($personal->birthdate) ? $personal->birthdate : old('birthdate')).'','placeholder' => 'Ingresa la fecha...']); ?>
             <?php $__env->slot('appendSlot', null, []); ?> 
                <div class="input-group-append">
                    <div class="input-group-text"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                </div>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8dc1514386dad8f66b5b18640b397fe)): ?>
<?php $attributes = $__attributesOriginalc8dc1514386dad8f66b5b18640b397fe; ?>
<?php unset($__attributesOriginalc8dc1514386dad8f66b5b18640b397fe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8dc1514386dad8f66b5b18640b397fe)): ?>
<?php $component = $__componentOriginalc8dc1514386dad8f66b5b18640b397fe; ?>
<?php unset($__componentOriginalc8dc1514386dad8f66b5b18640b397fe); ?>
<?php endif; ?>
    </div>

    <div class="col-6">
        <div class="form-group">
            <label for="civil_status">Estado Civil</label>
            <input type="text" class="form-control" id="civil_status" name="civil_status"
                placeholder="Ingrese su apellido"
                value="<?php echo e(isset($personal->civil_status) ? $personal->civil_status : old('civil_status')); ?>">
            <?php $__errorArgs = ['civil_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-6">
        <div class="form-group">
            <label for="sexo">Sexo</label>
            <input type="text" class="form-control" id="sexo" name="sexo" placeholder="Ingrese su apellido"
                value="<?php echo e(isset($personal->sexo) ? $personal->sexo : old('sexo')); ?>">
            <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-6">
        <div class="form-group">
            <label for="email">Correo</label>
            <input type="text" class="form-control" id="email" name="email" placeholder="Ingrese su apellido"
                value="<?php echo e(isset($personal->email) ? $personal->email : old('email')); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-6">
        <div class="form-group">
            <label for="address">Direccion</label>
            <input type="text" class="form-control" id="address" name="address" placeholder="Ingrese su apellido"
                value="<?php echo e(isset($personal->address) ? $personal->address : old('address')); ?>">
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-6">
        <div class="form-group">
            <label for="cellphone">Celular</label>
            <input type="text" class="form-control" id="cellphone" name="cellphone"
                placeholder="Ingrese su numero de celular"
                value="<?php echo e(isset($personal->cellphone) ? $personal->cellphone : old('cellphone')); ?>">
            <?php $__errorArgs = ['cellphone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-6">

        <div class="form-group">
            <label for="documento_identidad">Foto</label>
            <br>
            <img id="preview_img" src="<?php echo e(isset($personal->img_url) ? asset('storage/' . $personal->img_url) : ''); ?>"
                class="<?php echo e(isset($personal->img_url) ? '' : 'd-none'); ?>" alt="" width="100px"
                height="100px">

            <input type="file" id="personal_file" class="form-control" name="imagen" accept="image/*">
            <?php $__errorArgs = ['img_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        </div>

    </div>


    <div class="col-12">
        <hr>
    </div>
    <div class="col-12">
        <div class="form-group">
            <label for="email">Crear un usuario</label>
            <div class="row">
                <div class="col-4">

                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                        </div>
                        <input type="text" class="form-control" id="user" name="user"
                            placeholder="Ingrese su user"
                            value="<?php echo e(isset($personal->user->email) ? $personal->user->email : old('user')); ?>">

                    </div>
                    <?php $__errorArgs = ['user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="col-4">

                    <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-key"></i></span>
                        </div>
                        <input type="password" class="form-control" id="password" name="password"
                            placeholder="Ingrese su password"
                            value="<?php echo e(isset($personal->password) ? $personal->password : old('password')); ?>">

                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="col-4">
                    <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-key"></i></span>
                        </div>
                        <input type="password" class="form-control" id="password_confirmation" name="password_confirmation"
                            placeholder="confirme su password"
                            value="<?php echo e(isset($personal->password_confirmation) ? $personal->password_confirmation : old('password_confirmation')); ?>">

                    </div>
                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>



            </div>

        </div>
    </div>


</div>


<div class="container text-center mt-5">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Actualizar' : 'Guardar'); ?>">
</div>
<?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/personal/form-personal.blade.php ENDPATH**/ ?>