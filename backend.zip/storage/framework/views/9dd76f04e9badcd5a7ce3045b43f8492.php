<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <h2>Detalle de puntos</h2>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('dinamic-content'); ?>

<div class="container">
    <div class="row">
        <div class="col-12">
           <?php echo e(dd($personalPoints)); ?>


        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/points/points-detail.blade.php ENDPATH**/ ?>