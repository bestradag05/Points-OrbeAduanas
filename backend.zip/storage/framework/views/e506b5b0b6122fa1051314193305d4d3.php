<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <h2>Registra un rol</h2>
        <div>
            <a href="<?php echo e(url('/roles')); ?>" class="btn btn-primary"> Atras </a>
        </div>
    </div>

    <?php if(isset($error)): ?>
    <div class="alert alert-danger">
        <?php echo e($error); ?>

    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('dinamic-content'); ?>
    <form action="/roles" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('roles.form-roles', ['formMode' => 'create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>

   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/roles/register-roles.blade.php ENDPATH**/ ?>