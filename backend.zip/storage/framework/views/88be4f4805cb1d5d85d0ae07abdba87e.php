<div class="row">
    
    <div class="col-6">
        <div class="form-group">
            <label for="nro_orde">N° de Orden</label>
            <input type="text" class="form-control <?php $__errorArgs = ['nro_orde'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nro_orde"
                name="nro_orde" placeholder="Ingrese el numero de orden"
                value="<?php echo e(isset($custom->nro_orde) ? $custom->nro_orde : old('nro_orde')); ?>">
            <?php $__errorArgs = ['nro_orde'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="invalid-feedback d-block"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>

    <div class="col-6">
        <div class="form-group">
            <label for="nro_dua">N° de Dua</label>
            <input type="text" class="form-control <?php $__errorArgs = ['nro_dua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nro_dua"
                name="nro_dua" placeholder="Ingrese su numero de dua"
                value="<?php echo e(isset($custom->nro_dua) ? $custom->nro_dua : old('nro_dua')); ?>">
            <?php $__errorArgs = ['nro_dua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="invalid-feedback d-block"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-6">

        <div class="form-group">
            <label for="nro_dam">N° Dam</label>
            <input type="text" class="form-control <?php $__errorArgs = ['nro_dam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nro_dam"
                name="nro_dam" placeholder="Ingrese su numero de dam"
                value="<?php echo e(isset($custom->nro_dam) ? $custom->nro_dam : old('nro_dam')); ?>">
            <?php $__errorArgs = ['nro_dam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="invalid-feedback d-block"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>

    <div class="col-6">

        <?php
            $config = ['format' => 'DD/MM/YYYY'];

        ?>
        <?php if (isset($component)) { $__componentOriginalc8dc1514386dad8f66b5b18640b397fe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8dc1514386dad8f66b5b18640b397fe = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\InputDate::resolve(['name' => 'date_register','id' => 'date_register','label' => 'Fecha de Registro','config' => $config] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-input-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\InputDate::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(isset($custom->date_register) ? \Carbon\Carbon::parse($custom->date_register)->format('d/m/Y') : now()->format('d/m/Y')).'','placeholder' => 'Ingresa la fecha...']); ?>
             <?php $__env->slot('appendSlot', null, []); ?> 
                <div class="input-group-append">
                    <div class="input-group-text"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                </div>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8dc1514386dad8f66b5b18640b397fe)): ?>
<?php $attributes = $__attributesOriginalc8dc1514386dad8f66b5b18640b397fe; ?>
<?php unset($__attributesOriginalc8dc1514386dad8f66b5b18640b397fe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8dc1514386dad8f66b5b18640b397fe)): ?>
<?php $component = $__componentOriginalc8dc1514386dad8f66b5b18640b397fe; ?>
<?php unset($__componentOriginalc8dc1514386dad8f66b5b18640b397fe); ?>
<?php endif; ?>

    </div>


    <div class="col-6">

        <div class="form-group">
            <label for="cif_value">Valor CIF</label>
            <input type="text" class="form-control CurrencyInput <?php $__errorArgs = ['cif_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="cif_value" name="cif_value" data-type="currency" placeholder="Ingrese el valor cif"
                value="<?php echo e(isset($custom->cif_value) ? $custom->cif_value : ''); ?>">
            <?php $__errorArgs = ['cif_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="invalid-feedback d-block"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-6">
        <div class="form-group">
            <label for="channel">Canal</label>
            <select name="channel" class="form-control <?php $__errorArgs = ['channel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="channel">
                <option selected disabled>Selecciona un canal...</option>
                <option value="V" <?php echo e(old('channel') == 'V' || $custom->channel == 'V' ? 'selected' : ''); ?>>Verde
                </option>
                <option value="R" <?php echo e(old('channel') == 'R' || $custom->channel == 'R' ? 'selected' : ''); ?>>Rojo
                </option>
                <option value="N" <?php echo e(old('channel') == 'N' || $custom->channel == 'N' ? 'selected' : ''); ?>>
                    Naranja</option>
            </select>
            <?php $__errorArgs = ['channel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="invalid-feedback d-block"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>

    <div class="col-6">
        <div class="form-group">
            <label for="nro_bl">N° Bl</label>
            <input type="text" class="form-control <?php $__errorArgs = ['nro_bl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nro_bl"
                name="nro_bl" placeholder="Ingrese el numero de bl"
                value="<?php echo e(isset($custom->nro_bl) ? $custom->nro_bl : old('nro_bl')); ?>">
            <?php $__errorArgs = ['nro_bl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="invalid-feedback d-block"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>


    <div class="col-6">
        <label for="regularization_date">Fecha de reguralizacion</label>


        <?php if($custom->modality->name == 'DIFERIDO'): ?>
            <div class="input-group date" id="reguralization">

                <input type="text" class="form-control <?php $__errorArgs = ['regularization_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="regularization_date" data-target="#reguralization" <?php if(true): echo 'readonly'; endif; ?> value="NO REQUIERE">


                <div class="input-group-append" data-target="#reguralization" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                </div>
            </div>
        <?php else: ?>
            <div class="input-group date" id="reguralization" data-target-input="nearest">

                <input type="text" class="form-control <?php $__errorArgs = ['regularization_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="regularization_date" data-target="#reguralization"
                    value="<?php echo e(isset($custom->regularization_date) ? \Carbon\Carbon::parse($custom->date_register)->format('d/m/Y') : old('regularization_date')); ?>">


                <div class="input-group-append" data-target="#reguralization" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                </div>
            </div>
        <?php endif; ?>

        <strong class="invalid-feedback d-block text-warning">"Si no tiene ningun valor, por defecto se encuentra
            Pendiente"</strong>
        <?php $__errorArgs = ['regularization_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="invalid-feedback d-block"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>





</div>

<div class="container text-center mt-5">
    <input class="btn btn-primary" type="submit" value="Guardar">
</div>
<?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/custom/form-point-custom.blade.php ENDPATH**/ ?>