<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <h2><?php echo e($rol->name); ?></h2>
        <div>
            <a href="<?php echo e(url('/roles')); ?>" class="btn btn-primary"> Atras </a>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('dinamic-content'); ?>

    <div class="card card-primary card-outline card-outline-tabs">
        <div class="card-header p-0 border-bottom-0">
            <ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link <?php echo e($tab == 'usuarios' ? 'active' : ''); ?>"
                        href="<?php echo e(url('roles/grupos/' . $rol->id)); ?>">Usuarios</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($tab == 'usuarios' ? '' : 'active'); ?>"
                        href="<?php echo e(url('/roles/grupos/permissions/' . $rol->id)); ?>">Permisos (<?php echo e($rol->permissions->count()); ?>)</a>
                </li>
                <li class="nav-item">

            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content" id="custom-tabs-four-tabContent">
                <div class="tab-pane fade active show" id="custom-tabs-four-home" role="tabpanel"
                    aria-labelledby="custom-tabs-four-home-tab">

                    <?php if($tab == 'usuarios'): ?>
                        <?php echo $__env->make('roles/form-group-roles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php else: ?>
                        <?php echo $__env->make('permissions/list-permissions  ', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>

            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/roles/group-roles.blade.php ENDPATH**/ ?>