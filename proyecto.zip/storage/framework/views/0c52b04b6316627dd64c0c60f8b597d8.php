<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <h2>Registrar un proveedor</h2>
        <a href="<?php echo e(url('suppliers')); ?>" class="btn btn-primary">Atrás</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dinamic-content'); ?>
    <form action="<?php echo e(url('suppliers')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('supplier.form-supplier', ['formMode' => 'create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas - backend\resources\views/supplier/register-supplier.blade.php ENDPATH**/ ?>