<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConceptCustoms extends Model
{
    use HasFactory;


    protected $table = 'concepts_customs';

    protected $fillable =
    [
        'concepts_id',
        'id_customs',
        'value_concept',
        'value_sale',

    ];


    public function concept()
    {
        return $this->belongsTo(Concept::class, 'concepts_id');
    }

    // Relación con customs
    public function customs()
    {
        return $this->belongsTo(Custom::class, 'id_customs');
    }

}
