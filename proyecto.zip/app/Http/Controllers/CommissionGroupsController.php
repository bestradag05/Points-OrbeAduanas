<?php

namespace App\Http\Controllers;

use App\Models\CommissionGroups;
use Illuminate\Http\Request;

class CommissionGroupsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(CommissionGroups $commissionGroups)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CommissionGroups $commissionGroups)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, CommissionGroups $commissionGroups)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CommissionGroups $commissionGroups)
    {
        //
    }
}
