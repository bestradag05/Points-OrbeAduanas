<?php

namespace App\Http\Controllers;

use App\Models\QuoteSentClientConcept;
use App\Models\QuotesSentClient;
use Barryvdh\DomPDF\Facade\Pdf as FacadePdf;
use Barryvdh\DomPDF\PDF;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class QuoteSentClientConceptController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }


    /**
     * Display the specified resource.
     */
    public function show(QuoteSentClientConcept $quoteSentClientConcept)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(QuoteSentClientConcept $quoteSentClientConcept)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, QuoteSentClientConcept $quoteSentClientConcept)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(QuoteSentClientConcept $quoteSentClientConcept)
    {
        //
    }
}
