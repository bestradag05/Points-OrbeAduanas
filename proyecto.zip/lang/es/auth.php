<?php
return [
    'failed' => 'El usuario o la contraseña son incorrectos, intenta de nuevo.', # mensaje si no coinciden datos
    'throttle' => 'Muchos intentos de login. Intenta de nuevo en :seconds segundos.', # mensaje si intenta loguearse muchas veces y falla
];