<?php echo app('Illuminate\Foundation\Vite')(['resources/js/chartjs/points-chart.js']); ?>

<?php echo $__env->make('points.points-template', ['title' => 'Puntos de Flete', 'chart' => 'freight'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/points/points-freight.blade.php ENDPATH**/ ?>