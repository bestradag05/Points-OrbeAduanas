<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <h2>Registra un tipo de seguro</h2>
        <div>
            <a href="<?php echo e(url('/type_insurance')); ?>" class="btn btn-primary"> Atras </a>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('dinamic-content'); ?>
    <form action="/type_insurance" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('type_insurance.form-type_insurance', ['formMode' => 'create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/type_insurance/register-type_insurance.blade.php ENDPATH**/ ?>