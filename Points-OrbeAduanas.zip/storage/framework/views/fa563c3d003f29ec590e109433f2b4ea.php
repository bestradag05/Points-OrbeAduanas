<?php $__env->startSection('dinamic-content'); ?>
    <div class="d-flex justify-content-center">
        <h3 class="text-bold">Detalle de cotizacion para Nro de operacion : <span
                class="text-indigo"><?php echo e($quote->nro_operation); ?></span> </h3>
    </div>
    <div class="container">

        <div class="row">
            <div class="col-12 my-4 text-center">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transporte.quote.response')): ?>

                <button class="btn btn-indigo mx-2 <?php echo e($quote->state != 'Pendiente' ? 'd-none' : ''); ?>" data-toggle="modal"
                    data-target="#modalQuoteResponse"><i class="fas fa-check-double"></i> Dar respuesta</button>

                <button class="btn btn-secondary mx-2 <?php echo e($quote->state != 'Pendiente' ? 'd-none' : ''); ?>"
                    data-toggle="modal" data-target="#modalQuoteObservation"><i class="fas fa-eye"></i> Dar
                    observaciones</button>

                
                <?php endif; ?>

                <button class="btn btn-secondary mx-2 <?php echo e($quote->state != 'Reajuste' ? 'd-none' : ''); ?>" data-toggle="modal"
                    data-target="#modalQuoteReajust"><i class="fa-solid fa-money-check-dollar-pen"></i> Reajustar </button>

                <a href="<?php echo e(url('/quote/transport/cost/keep/' . $quote->id)); ?>"
                    class="btn btn-danger mx-2 <?php echo e($quote->state != 'Reajuste' ? 'd-none' : ''); ?>"><i
                        class="fa-solid fa-hand-holding-dollar"></i> Mantener precio </a>

            </div>

            <?php if($files->isNotEmpty()): ?>
                <div class="col-12 mb-2 row">
                    <h6 class="text-bold text-secondary ml-2">Documentos:</h6>
                    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mx-2">
                            <a href="<?php echo e($file['url']); ?>" class="mx-1" target="_blank"><?php echo e($file['name']); ?></a>
                            <i class="fas fa-file-archive"></i>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p class="text-bold text-secondary ml-2">No hay archivos adjuntos disponibles para esta cotizacion.</p>
            <?php endif; ?>

            <div class="col-12">

                <div class="head-quote mb-2">
                    <h5 id="title_quote" class="text-center text-uppercase bg-indigo p-2">Formato <span></span></h5>
                </div>
                <div class="body-detail-customer p-2">
                    <div class="form-group row">
                        <label for="customer" class="col-sm-2 col-form-label">Cliente</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['customer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="customer" name="customer" placeholder="Ingresa el cliente" <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->routing->customer) ? $quote->routing->customer->name_businessname : old('customer')); ?>">
                        </div>
                        <?php $__errorArgs = ['customer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row <?php echo e($quote->lcl_fcl === 'LCL' ? '' : 'd-none'); ?>">
                        <label for="pick_up" class="col-sm-2 col-form-label">Direccion de recojo</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['pick_up'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pick_up"
                                name="pick_up" placeholder="Ingrese la direccion de recojo" <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->pick_up) ? $quote->pick_up : old('pick_up')); ?>">
                            <?php $__errorArgs = ['pick_up'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>

                    <div class="form-group row  <?php echo e($quote->lcl_fcl === 'FCL' ? '' : 'd-none'); ?>">
                        <label for="pick_up" class="col-sm-2 col-form-label">Puerto / Almacen</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['pick_up'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pick_up"
                                name="pick_up" placeholder="Ingrese la direccion de recojo" <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->pick_up) ? $quote->pick_up : old('pick_up')); ?>">
                            <?php $__errorArgs = ['pick_up'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="delivery" class="col-sm-2 col-form-label">Direccion de entrega</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['delivery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="delivery" name="delivery" placeholder="Ingrese la direccion de entrega"
                                <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->delivery) ? $quote->delivery : old('delivery')); ?>">
                            <?php $__errorArgs = ['delivery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row <?php echo e($quote->lcl_fcl === 'FCL' ? '' : 'd-none'); ?>">
                        <label for="container_return" class="col-sm-2 col-form-label">Devolucion de contenedor</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['container_return'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="container_return" name="container_return"
                                placeholder="Ingrese donde se hara la devolucion" <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->container_return) ? $quote->container_return : old('container_return')); ?>">

                            <?php $__errorArgs = ['container_return'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="contact_name" class="col-sm-2 col-form-label">Nombre del contacto</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['contact_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="contact_name" name="contact_name" placeholder="Ingresa el nombre del contacto"
                                <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->contact_name) ? $quote->contact_name : old('contact_name')); ?>">
                        </div>
                        <?php $__errorArgs = ['contact_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row">
                        <label for="contact_phone" class="col-sm-2 col-form-label">Telefono del contacto</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="contact_phone" name="contact_phone"
                                placeholder="Ingresa el numero de celular del contacto" <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->contact_phone) ? $quote->contact_phone : old('contact_phone')); ?>">
                        </div>
                        <?php $__errorArgs = ['contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row">
                        <label for="max_attention_hour" class="col-sm-2 col-form-label">Hora maxima de entrega</label>
                        <?php
                            $config = ['format' => 'LT'];
                        ?>
                        <?php if (isset($component)) { $__componentOriginalc8dc1514386dad8f66b5b18640b397fe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8dc1514386dad8f66b5b18640b397fe = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\InputDate::resolve(['name' => 'max_attention_hour','config' => $config] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-input-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\InputDate::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true,'placeholder' => 'Ingrese la hora maxima de entrega','value' => ''.e(isset($quote->max_attention_hour) ? $quote->max_attention_hour : old('max_attention_hour')).'']); ?>
                             <?php $__env->slot('prependSlot', null, []); ?> 
                                <div class="input-group-text bg-gradient-indigo">
                                    <i class="fas fa-clock"></i>
                                </div>
                             <?php $__env->endSlot(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8dc1514386dad8f66b5b18640b397fe)): ?>
<?php $attributes = $__attributesOriginalc8dc1514386dad8f66b5b18640b397fe; ?>
<?php unset($__attributesOriginalc8dc1514386dad8f66b5b18640b397fe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8dc1514386dad8f66b5b18640b397fe)): ?>
<?php $component = $__componentOriginalc8dc1514386dad8f66b5b18640b397fe; ?>
<?php unset($__componentOriginalc8dc1514386dad8f66b5b18640b397fe); ?>
<?php endif; ?>

                    </div>
                    <div class="form-group row">
                        <label for="gang" class="col-sm-2 col-form-label">Cuadrilla</label>
                        <div class="col-sm-10">
                            <div class="form-check d-inline">
                                <input type="radio" id="radioLclFcl" name="gang" value="SI"
                                    class="form-check-input <?php $__errorArgs = ['gang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    <?php echo e($quote->gang === 'SI' ? 'checked ' : 'disabled'); ?>>
                                <label for="radioLclFcl" class="form-check-label">
                                    SI
                                </label>
                            </div>
                            <div class="form-check d-inline">
                                <input type="radio" id="radioLclFcl" name="gang" value="NO"
                                    class="form-check-input <?php $__errorArgs = ['gang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    <?php echo e($quote->gang === 'NO' ? 'checked' : 'disabled'); ?>>
                                <label for="radioLclFcl" class="form-check-label">
                                    NO
                                </label>
                            </div>

                            <?php $__errorArgs = ['gang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    <div class="form-group row  <?php echo e($quote->lcl_fcl === 'FCL' ? '' : 'd-none'); ?>">
                        <label for="guard" class="col-sm-2 col-form-label">Resguardo</label>
                        <div class="col-sm-10">
                            <div class="form-check d-inline">
                                <input type="radio" id="radioGuard" name="guard" value="SI"
                                    class="form-check-input <?php $__errorArgs = ['guard'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    <?php echo e($quote->guard === 'SI' ? 'checked' : 'disabled'); ?>>
                                <label for="radioGuard" class="form-check-label">
                                    SI
                                </label>
                            </div>
                            <div class="form-check d-inline">
                                <input type="radio" id="radioGuard" name="guard" value="NO"
                                    class="form-check-input <?php $__errorArgs = ['guard'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    <?php echo e($quote->guard === 'NO' ? 'checked' : 'disabled'); ?>>
                                <label for="radioGuard" class="form-check-label">
                                    NO
                                </label>
                            </div>

                            <?php $__errorArgs = ['guard'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="customer_detail" class="col-sm-2 col-form-label">Detalles</label>
                        <div class="col-sm-10">
                            <textarea class="form-control <?php $__errorArgs = ['customer_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="customer_detail"
                                name="customer_detail" placeholder="Ingresa un detalle o alguna observacion" <?php if(true): echo 'readonly'; endif; ?>><?php echo e(isset($quote->customer_detail) ? $quote->customer_detail : ''); ?></textarea>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-12">

                <div class="head-quote mb-2">
                    <h5 id="title_quote" class="text-center text-uppercase bg-indigo p-2">Detalle de carga <span></span>
                    </h5>
                </div>
                <div class="body-detail-product p-2">
                    <div class="form-group row">
                        <label for="load_type" class="col-sm-2 col-form-label">Tipo de Carga</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['load_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="load_type" name="load_type" placeholder="Ingrese el tipo de carga" <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->load_type) ? $quote->load_type : old('load_type')); ?>">
                        </div>
                        <?php $__errorArgs = ['load_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row">
                        <label for="commodity" class="col-sm-2 col-form-label">Descripcion</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['commodity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="commodity" name="commodity" placeholder="Ingrese descripcion del producto"
                                <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->commodity) ? $quote->commodity : old('commodity')); ?>">
                        </div>
                        <?php $__errorArgs = ['commodity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row  <?php echo e($quote->lcl_fcl === 'FCL' ? '' : 'd-none'); ?>">
                        <label for="container_type" class="col-sm-2 col-form-label">Tipo de contenedor</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['container_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="container_type" name="container_type" placeholder="Ingrese el tipo de contenedor"
                                <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->container_type) ? $quote->container_type : old('container_type')); ?>">


                            <?php $__errorArgs = ['container_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                    </div>
                    <div class="form-group row  <?php echo e($quote->lcl_fcl === 'FCL' ? '' : 'd-none'); ?>">
                        <label for="ton_kilogram" class="col-sm-2 col-form-label">Toneladas / KG</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['ton_kilogram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="ton_kilogram" name="ton_kilogram" placeholder="Ingrese el preso de carga"
                                <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->ton_kilogram) ? $quote->ton_kilogram : old('ton_kilogram')); ?>">

                            <?php $__errorArgs = ['ton_kilogram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="packaging_type" class="col-sm-2 col-form-label">Tipo de embalaje</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['packaging_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="packaging_type" name="packaging_type" placeholder="Ingrese el tipo de embalaje"
                                <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->packaging_type) ? $quote->packaging_type : old('packaging_type')); ?>">
                        </div>
                        <?php $__errorArgs = ['packaging_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row <?php echo e($quote->lcl_fcl === 'LCL' ? '' : 'd-none'); ?>">
                        <label for="stackable" class="col-sm-2 col-form-label">Apilable</label>
                        <div class="col-sm-10">
                            <div class="form-check d-inline">
                                <input type="radio" id="radioStackable" name="stackable" value="SI"
                                    class="form-check-input <?php $__errorArgs = ['stackable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    <?php echo e($quote->stackable === 'SI' ? 'checked' : 'disabled'); ?>>
                                <label for="radioStackable" class="form-check-label">
                                    SI
                                </label>
                            </div>
                            <div class="form-check d-inline">
                                <input type="radio" id="radioStackable" name="stackable" value="NO"
                                    class="form-check-input  <?php $__errorArgs = ['stackable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    <?php echo e($quote->stackable === 'NO' ? 'checked' : 'disabled'); ?>>
                                <label for="radioStackable" class="form-check-label">
                                    NO
                                </label>
                            </div>
                            <?php $__errorArgs = ['stackable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    <div class="form-group row <?php echo e($quote->lcl_fcl === 'LCL' ? '' : 'd-none'); ?>">
                        <label for="cubage_kgv" class="col-sm-2 col-form-label">Cubicaje/KGV</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['cubage_kgv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="cubage_kgv" name="cubage_kgv" placeholder="Ingresa el cubicaje / kgv"
                                <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->cubage_kgv) ? $quote->cubage_kgv : old('cubage_kgv')); ?>">
                            <?php $__errorArgs = ['cubage_kgv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row <?php echo e($quote->lcl_fcl === 'LCL' ? '' : 'd-none'); ?>">
                        <label for="total_weight" class="col-sm-2 col-form-label">Peso total</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['total_weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="total_weight" name="total_weight"
                                placeholder="Ingresa la hora maxima de recojo del cliente" <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->total_weight) ? $quote->total_weight : old('total_weight')); ?>">
                        </div>
                        <?php $__errorArgs = ['total_weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row">
                        <label for="packages" class="col-sm-2 col-form-label">Bultos</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php $__errorArgs = ['packages'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="packages" name="packages" placeholder="Ingresa el valor de los bultos"
                                <?php if(true): echo 'readonly'; endif; ?>
                                value="<?php echo e(isset($quote->packages) ? $quote->packages : old('packages')); ?>">
                        </div>
                        <?php $__errorArgs = ['packages'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="cargo_detail" class="col-sm-2 col-form-label">Detalles</label>
                        <div class="col-sm-10">
                            <textarea class="form-control <?php $__errorArgs = ['cargo_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="cargo_detail" name="cargo_detail"
                                placeholder="Ingresa un detalle o alguna observacion" <?php if(true): echo 'readonly'; endif; ?>> <?php echo e(isset($quote->cargo_detail) ? $quote->cargo_detail : ''); ?></textarea>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-12">

                <div class="head-quote mb-2">
                    <h5 class="text-center text-uppercase bg-indigo p-2">Medidas</h5>
                </div>
                <div class="body-detail-product p-2">

                    <table id="table_measures" class="table table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th>Cantidad</th>
                                <th>Ancho (cm)</th>
                                <th>Largo (cm)</th>
                                <th>Alto (cm)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = json_decode($quote->measures); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $measure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($measure->amount); ?></td>
                                <td><?php echo e($measure->height); ?></td>
                                <td><?php echo e($measure->length); ?></td>
                                <td><?php echo e($measure->width); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>

                    <input type="hidden" id="measures" name="measures">
                    <input type="hidden" id="nro_operation" name="nro_operation"
                        value="<?php echo e(isset($quote->nro_operation) ? $quote->nro_operation : old('nro_operation')); ?>">
                    <input type="hidden" id="lcl_fcl" name="lcl_fcl">

                </div>

            </div>


        </div>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="modalQuoteResponse" tabindex="-1" aria-labelledby="modalQuoteResponseLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action=<?php echo e(url('/quote/transport/cost/' . $quote->id)); ?> id="sendTransportCost" method="POST"
                    enctype="multipart/form-data">
                    <?php echo e(method_field('PATCH')); ?>

                    <?php echo e(csrf_field()); ?>

                    <div class="modal-header">
                        <h5 class="modal-title" id="modalQuoteResponseLabel">PRECIO DE FLETE DE TRANSPORTE</h5>
                    </div>
                    <div class="modal-body">
                        <div class="form-group row">
                            <label for="pounds" class="col-sm-4 col-form-label">Costo transporte: </label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control CurrencyInput" data-type="currency"
                                    name="modal_transport_cost" id="modal_transport_cost"
                                    placeholder="Ingrese costo de flete de transporte..">
                            </div>
                        </div>
                        <div id="container_gang"
                            class="form-group row <?php echo e(isset($quote->gang) && $quote->gang === 'SI' ? '' : 'd-none'); ?>">
                            <label for="pounds" class="col-sm-4 col-form-label">Costo de Cuadrilla: </label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control CurrencyInput" data-type="currency"
                                    name="cost_gang" id="cost_gang" placeholder="Ingrese costo de cuadrilla..">
                            </div>
                        </div>
                        <div id="container_guard"
                            class="form-group row <?php echo e(isset($quote->guard) && $quote->guard === 'SI' ? '' : 'd-none'); ?>">
                            <label for="pounds" class="col-sm-4 col-form-label">Costo de Resguardo: </label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control CurrencyInput" data-type="currency"
                                    name="cost_guard" id="cost_guard" placeholder="Ingrese costo de resguardo..">
                            </div>
                        </div>

                        <span id="error_transport_cost" class="invalid-feedback d-none" role="alert">
                            <strong id="texto_transport_cost"></strong>
                        </span>

                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="submit" class="btn btn-primary">Enviar costo</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modalQuoteReajust" tabindex="-1" aria-labelledby="modalQuoteReajustLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action=<?php echo e(url('/quote/transport/cost/responsereajust/' . $quote->id)); ?> id="sendTransportReajust"
                    method="POST" enctype="multipart/form-data">
                    <?php echo e(method_field('PATCH')); ?>

                    <?php echo e(csrf_field()); ?>

                    <div class="modal-header">
                        <h5 class="modal-title" id="modalQuoteReajustLabel">REAJUSTE DE PRECIO DE FLETE DE TRANSPORTE</h5>
                    </div>
                    <div class="modal-body">

                        <div class="form-group row">
                            <label for="pounds" class="col-sm-4 col-form-label">Observacion : </label>
                            <div class="col-sm-8">
                                <textarea type="text" class="form-control" name="readjustment_reason" id="readjustment_reason"
                                    <?php if(true): echo 'readonly'; endif; ?>><?php echo e(isset($quote->readjustment_reason) ? $quote->readjustment_reason : ''); ?></textarea>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="pounds" class="col-sm-4 col-form-label">Costo de transporte: </label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control CurrencyInput" data-type="currency"
                                    name="modal_transport_old_cost" id="modal_transport_old_cost"
                                    placeholder="Ingrese costo de flete de transporte.."
                                    value="<?php echo e(isset($quote->cost_transport) ? $quote->cost_transport : ''); ?>"
                                    <?php if(true): echo 'readonly'; endif; ?>>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="pounds" class="col-sm-4 col-form-label">Costo reajustado: </label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control CurrencyInput" data-type="currency"
                                    name="modal_transport_readjustment_cost" id="modal_transport_readjustment_cost"
                                    placeholder="Ingrese costo de flete de transporte..">

                                <span id="required_reajust_transport_cost" class="invalid-feedback d-none"
                                    role="alert">
                                    <strong id="texto_reajust_transport_cost">Complete el campo de costo de
                                        reajuste</strong>
                                </span>

                                <span id="value_reajust_transport_cost" class="invalid-feedback d-none" role="alert">
                                    <strong id="texto_reajust_transport_cost">El costo de reajuste no puede ser mayor o
                                        igual que el costo actual</strong>
                                </span>

                            </div>

                        </div>



                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="submit" class="btn btn-primary">Enviar costo</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modalQuoteObservation" tabindex="-1" aria-labelledby="modalQuoteObservationLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action=<?php echo e(url('/quote/transport/cost/observation/' . $quote->id)); ?> id="sendTransportObservation"
                    method="POST" enctype="multipart/form-data">
                    <?php echo e(method_field('PATCH')); ?>

                    <?php echo e(csrf_field()); ?>

                    <div class="modal-header">
                        <h5 class="modal-title" id="modalQuoteObservationLabel">Observaciones de cotización
                        </h5>
                    </div>
                    <div class="modal-body">


                        <div class="form-group row flex-column">
                            <label for="obse" class="col-sm-6 col-form-label">Observacion :</label>
                            <div class="col-sm-12">
                                <textarea type="text" class="form-control" name="observations" id="observations" rows="5"></textarea>
                            </div>
                        </div>


                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="submit" class="btn btn-primary">Enviar observaciones</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modalQuoteObservationMessage" tabindex="-1"
        aria-labelledby="modalQuoteObservationMessage" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action=<?php echo e(url('/quote/transport/cost/observation/' . $quote->id)); ?> id="sendTransportObservation"
                    method="POST" enctype="multipart/form-data">
                    <?php echo e(method_field('PATCH')); ?>

                    <?php echo e(csrf_field()); ?>

                    <div class="modal-header">
                        <h5 class="modal-title" id="modalQuoteObservationMessage">Observaciones de cotización
                        </h5>
                    </div>
                    <div class="modal-body">


                        <div class="form-group row flex-column">
                            <label for="obse" class="col-sm-6 col-form-label">Observacion :</label>
                            <div class="col-sm-12">
                                <textarea type="text" class="form-control" name="observations" id="observations" rows="5"
                                    <?php if(true): echo 'readonly'; endif; ?>><?php echo e($quote->observations); ?></textarea>
                            </div>
                        </div>


                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#sendTransportCost').on('submit', (e) => {

            e.preventDefault();

            const containerGangVisibility = !$('#container_gang').hasClass('d-none');
            const containerGuardVisibility = !$('#container_guard').hasClass('d-none');


            const transport_cost = $('#modal_transport_cost').val().trim();

            if (transport_cost === '') {

                $('#modal_transport_cost').addClass('is-invalid');
                $('#error_transport_cost').removeClass('d-block').addClass('d-none');

                return;

            }else{
                $('#modal_transport_cost').removeClass('is-invalid');
            }

            if (containerGangVisibility) {
                if ($('#container_gang').find('input').val().trim() === '') {
                    $('#container_gang').find('input').addClass('is-invalid');

                    return;
                }else{
                    $('#container_gang').find('input').removeClass('is-invalid');
                }
            }

            if (containerGuardVisibility) {
                if ($('#container_guard').find('input').val().trim() === '') {
                    $('#container_guard').find('input').addClass('is-invalid');

                    return;
                }else{
                    $('#container_guard').find('input').removeClass('is-invalid');
                }
            }
           

            e.target.submit();


        });


        $('#sendTransportReajust').on('submit', (e) => {

            e.preventDefault();

            let currentCost = $('#modal_transport_readjustment_cost').val();
            let oldCost = $('#modal_transport_old_cost').val();



            if (currentCost === '') {

                $('#modal_transport_readjustment_cost').addClass('is-invalid');
                $('#required_reajust_transport_cost').removeClass('d-none').addClass('d-block');



            } else {

                $('#modal_transport_readjustment_cost').removeClass('is-invalid');
                $('#required_reajust_transport_cost').removeClass('d-block').addClass('d-none');

                let parseCurrentCost = parseFloat(currentCost.replace(/,/g, ''));
                let parseOldCost = parseFloat(oldCost.replace(/,/g, ''));


                if (parseCurrentCost >= parseOldCost) {

                    $('#modal_transport_readjustment_cost').addClass('is-invalid');
                    $('#value_reajust_transport_cost').removeClass('d-none').addClass('d-block');

                } else {
                    $('#modal_transport_readjustment_cost').removeClass('is-invalid');
                    $('#value_reajust_transport_cost').removeClass('d-block').addClass('d-none');

                    e.target.submit();

                }

            }

        });

        $('#sendTransportObservation').on('submit', (e) => {

            e.preventDefault();

            let observations = $('#observations').val().trim();


            if (observations === "") {
                $('#observations').addClass('is-invalid');
            } else {
                $('#modal_transport_readjustment_cost').removeClass('is-invalid');
                e.target.submit();
            }



        });
    </script>

    <?php if($quote->observations): ?>
        <script>
            $('#modalQuoteObservationMessage').modal('show');
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/transport/quote/detail-quote.blade.php ENDPATH**/ ?>