<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <h2>Actualizar un Routing</h2>
        <div>
            <button class="btn btn-primary"> Atras </button>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('dinamic-content'); ?>

    <div id="stepper" class="bs-stepper linear">
        <div class="bs-stepper-header" role="tablist">
            <div class="step active" data-target="#test-l-1">
                <button type="button" class="step-trigger" role="tab" id="stepper1trigger1"
                    aria-controls="test-l-1" aria-selected="true">
                    <span class="bs-stepper-circle">1</span>
                    <span class="bs-stepper-label">Informacion</span>
                </button>
            </div>
            <div class="bs-stepper-line"></div>
            <div class="step" data-target="#test-l-2">
                <button type="button" class="step-trigger" role="tab" id="stepper1trigger2"
                    aria-controls="test-l-2" aria-selected="false" disabled="disabled">
                    <span class="bs-stepper-circle">2</span>
                    <span class="bs-stepper-label">Detalle del Producto</span>
                </button>
            </div>
            
        </div>
        <div class="bs-stepper-content">
            <form onsubmit="return false;" action=<?php echo e('/routing/'. $routing->id); ?> id="formRouting" method="POST" enctype="multipart/form-data">
                <?php echo e(method_field('PATCH')); ?>

                <?php echo e(csrf_field()); ?>

                <?php echo $__env->make('routing.form-routing', ['formMode' => 'edit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </div>

   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/routing/edit-routing.blade.php ENDPATH**/ ?>