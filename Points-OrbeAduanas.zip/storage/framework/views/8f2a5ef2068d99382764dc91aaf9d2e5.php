<div class="row">
    

    <div class="col-6">
       
            <?php
                $config = ['format' => 'DD/MM/YYYY'];

            ?>
            <?php if (isset($component)) { $__componentOriginalc8dc1514386dad8f66b5b18640b397fe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8dc1514386dad8f66b5b18640b397fe = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\InputDate::resolve(['name' => 'date_register','id' => 'date_register','label' => 'Fecha de registro','config' => $config] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-input-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\InputDate::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(isset($freight->date_register) ? \Carbon\Carbon::parse($freight->date_register)->format('d/m/Y') : now()->format('d/m/Y')).'','placeholder' => 'Ingresa la fecha...']); ?>
                 <?php $__env->slot('appendSlot', null, []); ?> 
                    <div class="input-group-append">
                        <div class="input-group-text"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                    </div>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8dc1514386dad8f66b5b18640b397fe)): ?>
<?php $attributes = $__attributesOriginalc8dc1514386dad8f66b5b18640b397fe; ?>
<?php unset($__attributesOriginalc8dc1514386dad8f66b5b18640b397fe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8dc1514386dad8f66b5b18640b397fe)): ?>
<?php $component = $__componentOriginalc8dc1514386dad8f66b5b18640b397fe; ?>
<?php unset($__componentOriginalc8dc1514386dad8f66b5b18640b397fe); ?>
<?php endif; ?>

    </div>

    <div class="col-6">
        <div class="form-group">
            <label for="roi">ROI</label>
            <input type="text" class="form-control <?php $__errorArgs = ['roi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="roi" name="roi"
                placeholder="Ingrese el numero de ROI" value="<?php echo e(isset($freight->roi) ? $freight->roi : old('roi')); ?>">
            <?php $__errorArgs = ['roi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="invalid-feedback d-block"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>

    <div class="col-6">
        <div class="form-group">
            <label for="hawb_hbl">Hawb / HBL</label>
            <input type="text" class="form-control <?php $__errorArgs = ['hawb_hbl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="hawb_hbl"
                name="hawb_hbl" placeholder="Ingrese su numero de Hawb/HBL"
                value="<?php echo e(isset($freight->hawb_hbl) ? $freight->hawb_hbl : old('hawb_hbl')); ?>">
            <?php $__errorArgs = ['hawb_hbl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="invalid-feedback d-block"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>


    <div class="col-6">

        <?php
            $config = ['format' => 'DD/MM/YYYY'];

        ?>
        <?php if (isset($component)) { $__componentOriginalc8dc1514386dad8f66b5b18640b397fe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8dc1514386dad8f66b5b18640b397fe = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\InputDate::resolve(['name' => 'edt','id' => 'edt','label' => 'Fecha de arribo','config' => $config] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-input-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\InputDate::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(isset($freight->edt) ? \Carbon\Carbon::parse($freight->edt)->format('d/m/Y') : now()->format('d/m/Y')).'','placeholder' => 'Ingresa la fecha...']); ?>
             <?php $__env->slot('appendSlot', null, []); ?> 
                <div class="input-group-append">
                    <div class="input-group-text"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                </div>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8dc1514386dad8f66b5b18640b397fe)): ?>
<?php $attributes = $__attributesOriginalc8dc1514386dad8f66b5b18640b397fe; ?>
<?php unset($__attributesOriginalc8dc1514386dad8f66b5b18640b397fe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8dc1514386dad8f66b5b18640b397fe)): ?>
<?php $component = $__componentOriginalc8dc1514386dad8f66b5b18640b397fe; ?>
<?php unset($__componentOriginalc8dc1514386dad8f66b5b18640b397fe); ?>
<?php endif; ?>

    </div>

    <div class="col-6">

        <?php
            $config = ['format' => 'DD/MM/YYYY'];

        ?>
        <?php if (isset($component)) { $__componentOriginalc8dc1514386dad8f66b5b18640b397fe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8dc1514386dad8f66b5b18640b397fe = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\InputDate::resolve(['name' => 'eta','id' => 'eta','label' => 'Fecha de Llegada','config' => $config] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-input-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\InputDate::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(isset($freight->eta) ? \Carbon\Carbon::parse($freight->eta)->format('d/m/Y') : now()->format('d/m/Y')).'','placeholder' => 'Ingresa la fecha...']); ?>
             <?php $__env->slot('appendSlot', null, []); ?> 
                <div class="input-group-append">
                    <div class="input-group-text"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                </div>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8dc1514386dad8f66b5b18640b397fe)): ?>
<?php $attributes = $__attributesOriginalc8dc1514386dad8f66b5b18640b397fe; ?>
<?php unset($__attributesOriginalc8dc1514386dad8f66b5b18640b397fe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8dc1514386dad8f66b5b18640b397fe)): ?>
<?php $component = $__componentOriginalc8dc1514386dad8f66b5b18640b397fe; ?>
<?php unset($__componentOriginalc8dc1514386dad8f66b5b18640b397fe); ?>
<?php endif; ?>

    </div>



    <div class="col-6">

        <div class="form-group">
            <label for="bl_work">BL a trabajar</label>
            <input type="text" class="form-control <?php $__errorArgs = ['bl_work'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bl_work"
                name="bl_work" placeholder="Ingrese su numero de BL"
                value="<?php echo e(isset($freight->bl_work) ? $freight->bl_work : old('bl_work')); ?>">
            <?php $__errorArgs = ['bl_work'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="invalid-feedback d-block"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>


    <div class="col-6">

        <div class="form-group">
            <label for="value_utility">Utilidad</label>
            <input type="number" class="form-control <?php $__errorArgs = ['value_utility'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="value_utility"
                <?php if(true): echo 'readonly'; endif; ?> name="value_utility" placeholder="Ingrese su numero de dam"
                value="<?php echo e(isset($freight->value_utility) ? $freight->value_utility : old('value_utility')); ?>">
            <?php $__errorArgs = ['value_utility'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="invalid-feedback d-block"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>


    <div class="col-6">

        <div class="form-group">
            <label for="value_freight">Valor del Flete</label>
            <input type="number" class="form-control <?php $__errorArgs = ['value_freight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" <?php if(true): echo 'readonly'; endif; ?>
                id="value_freight" name="value_freight" placeholder="Ingrese el valor cif"
                value="<?php echo e(isset($freight->value_freight) ? $freight->value_freight : number_format($value_freight, 2)); ?>">
            <?php $__errorArgs = ['value_freight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="invalid-feedback d-block"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

</div>

<div class="container text-center mt-5">
    <input class="btn btn-primary" type="submit" value="Guardar">
</div>
<?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/freight/form-point-freight.blade.php ENDPATH**/ ?>