<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Exportacion de aduanas</title>
    <style>
         #tabla_custom {
            font-size: 12px;
            text-align: center;
            border-collapse: collapse;
         } 

       
         th, td {
            border: 1px solid black; /* Agrega bordes a las celdas */
            padding: 3px; /* Espaciado interno */
            text-align: center; /* Centra el texto */
        }

        #tabla_custom thead {
            background: #2e37a4;
            color: #fff;
        }

        #tabla_custom thead tr th{
            width: 65px;
        }
    </style>
</head>

<body>


    <table id="tabla_custom" class="table table-light">
        <thead class="thead-light">
            <tr>
                <th>#</th>
                <th>N° Orden</th>
                <th>Cliente</th>
                <th>Ruc</th>
                <th>Nro Dam</th>
                <th>Fecha</th>
                <th>Tipo de Embarque</th>
                <th>Modalidad</th>
                <th>Regimen</th>
                <th>Valor CIF</th>
                <th>Vendedor</th>
                <th>Canal</th>
                <th>N° Bl/AW</th>
                <th>Fecha de Regularizacion</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $customs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $custom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($custom->nro_orde); ?></td>
                    <td><?php echo e($custom->routing->customer->name_businessname); ?></td>
                    <td><?php echo e($custom->routing->customer->document_number); ?></td>
                    <td><?php echo e($custom->nro_dam); ?></td>
                    <td><?php echo e($custom->date_register); ?></td>
                    <td><?php echo e($custom->routing->type_shipment->code); ?></td>
                    <td><?php echo e($custom->modality->name); ?></td>
                    <td><?php echo e($custom->routing->regime->code); ?></td>
                    <td><?php echo e($custom->cif_value); ?></td>
                    <td><?php echo e($custom->routing->personal->names); ?></td>
                    <td><?php echo e($custom->channel); ?></td>
                    <td><?php echo e($custom->nro_bl); ?></td>
                    <td><?php echo e($custom->regularization_date); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>

</body>

</html>
<?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/points/exports/custom/custom-export.blade.php ENDPATH**/ ?>