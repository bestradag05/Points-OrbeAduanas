<?php $__env->startSection('content_header'); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('dinamic-content'); ?>

    <div class="d-flex justify-content-center mb-5">
        <h2><?php echo e($title); ?></h2>
    </div>

    <div class="container-fluid">
        <div class="row justify-content-center align-items-center flex-row ">

            <div class="col-4 text-center offset-4">

                
                <?php
                    $config = [
                        'showDropdowns' => true,
                        'startDate' => 'js:moment().startOf("month")',
                        'endDate' => 'js:moment().endOf("month")',
                        'minYear' => 2010,
                        'maxYear' => "js:parseInt(moment().format('YYYY'),10)",
                        'locale' => [
                            'format' => 'DD/MM/YYYY',
                            'separator' => ' - ',
                            'applyLabel' => 'Aplicar',
                            'cancelLabel' => 'Cancelar',
                            'fromLabel' => 'Desde',
                            'toLabel' => 'Hasta',
                            'customRangeLabel' => 'Personalizado',
                            'weekLabel' => 'S',
                            'daysOfWeek' => ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'],
                            'monthNames' => [
                                'Enero',
                                'Febrero',
                                'Marzo',
                                'Abril',
                                'Mayo',
                                'Junio',
                                'Julio',
                                'Agosto',
                                'Septiembre',
                                'Octubre',
                                'Noviembre',
                                'Diciembre',
                            ],
                            'firstDay' => 1, // 0 es domingo, 1 es lunes
                        ],
                        'opens' => 'center',
                    ];
                ?>
                <?php if (isset($component)) { $__componentOriginal5b443f27b4cfa4aecd210c5dc80c0c63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b443f27b4cfa4aecd210c5dc80c0c63 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\DateRange::resolve(['name' => 'points_date_range','igroupSize' => 'md','config' => $config] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-date-range'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\DateRange::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('prependSlot', null, []); ?> 
                        <div class="input-group-text text-indigo">
                            <i class="fas fa-calendar-alt"></i>
                        </div>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('appendSlot', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginal84b78d66d5203b43b9d8c22236838526 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84b78d66d5203b43b9d8c22236838526 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Button::resolve(['theme' => 'outline-indigo','label' => 'Buscar','icon' => 'fas fa-search'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'searchPoint']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $attributes = $__attributesOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__attributesOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $component = $__componentOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__componentOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b443f27b4cfa4aecd210c5dc80c0c63)): ?>
<?php $attributes = $__attributesOriginal5b443f27b4cfa4aecd210c5dc80c0c63; ?>
<?php unset($__attributesOriginal5b443f27b4cfa4aecd210c5dc80c0c63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b443f27b4cfa4aecd210c5dc80c0c63)): ?>
<?php $component = $__componentOriginal5b443f27b4cfa4aecd210c5dc80c0c63; ?>
<?php unset($__componentOriginal5b443f27b4cfa4aecd210c5dc80c0c63); ?>
<?php endif; ?>


            </div>

            <div class="col-4 row justify-content-center">
                
                
                <div class="mx-2 "><a href="#" id="pdf" class="text-indigo"><i
                            class="fa-sharp fa-xl fa-solid fa-file-pdf"></i></a></div>
                <div class="mx-2">
                    <a href="#" id="excel" class="text-indigo"> 
                        <i class="fa-sharp fa-xl fa-solid fa-file-excel"></i>
                    </a>
                </div>
            </div>


            <div class="col-8 my-5 ">
                <canvas id="<?php echo e($chart); ?>"></canvas>
            </div>



            <div class="col-10 row justify-content-center mt-2 ">

                
                <?php
                    $heads = ['#', 'Asesor', 'Nombre', 'Puntos'];

                ?>

                
                <?php if (isset($component)) { $__componentOriginal1f0f987500f76b1f57bfad21f77af286 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f0f987500f76b1f57bfad21f77af286 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::resolve(['id' => 'table-points','heads' => $heads] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f0f987500f76b1f57bfad21f77af286)): ?>
<?php $attributes = $__attributesOriginal1f0f987500f76b1f57bfad21f77af286; ?>
<?php unset($__attributesOriginal1f0f987500f76b1f57bfad21f77af286); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f0f987500f76b1f57bfad21f77af286)): ?>
<?php $component = $__componentOriginal1f0f987500f76b1f57bfad21f77af286; ?>
<?php unset($__componentOriginal1f0f987500f76b1f57bfad21f77af286); ?>
<?php endif; ?>

            </div>

        </div>


    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Points-OrbeAduanas\resources\views/points/points-template.blade.php ENDPATH**/ ?>